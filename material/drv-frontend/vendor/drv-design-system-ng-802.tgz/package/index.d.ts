import * as _angular_core from '@angular/core';
import { OnInit, OnDestroy, OnChanges, SimpleChanges, TemplateRef, ElementRef, AfterViewInit, EventEmitter, ChangeDetectorRef, AfterContentInit, QueryList, PipeTransform, InjectionToken } from '@angular/core';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { ControlValueAccessor, Validator, FormControl, UntypedFormGroup, FormGroup, FormControlName } from '@angular/forms';
import { Route, NavigationExtras } from '@angular/router';
import { MaskitoOptions } from '@maskito/core';
import { DomSanitizer } from '@angular/platform-browser';
import { TemplatePortal, ComponentPortal } from '@angular/cdk/portal';
import { BreakpointState } from '@angular/cdk/layout';
import { FocusOrigin } from '@angular/cdk/a11y';
import { createCurrentTimePlugin } from '@schedule-x/current-time';
import { createEventsServicePlugin } from '@schedule-x/events-service';
import { createCalendarControlsPlugin } from '@schedule-x/calendar-controls';
import { CalendarEvent, CalendarApp } from '@schedule-x/calendar';
export { CalendarEvent } from '@schedule-x/calendar';

type IconType = 'allergy' | 'archive' | 'arrow-back-to-top' | 'arrow-breadcrumb' | 'arrow-down' | 'arrow-external-small' | 'arrow-external' | 'arrow-left' | 'arrow-right' | 'arrow-to-top' | 'arrow-up' | 'attachment' | 'attention' | 'average' | 'bell' | 'bend' | 'bike' | 'billard' | 'blocker' | 'blood-type' | 'book-preview' | 'book' | 'build' | 'buildings' | 'bullet-check' | 'burger-search' | 'burger' | 'buttonblue' | 'buttonwhite' | 'calendar' | 'capital-dash' | 'capital' | 'card-reader' | 'check' | 'chevron-down' | 'chevron-first' | 'chevron-last' | 'chevron-left' | 'chevron-right' | 'chevron-up' | 'child' | 'clock' | 'close' | 'coins' | 'column-order' | 'contact-options' | 'contrast' | 'copy' | 'cube' | 'culture' | 'cursor' | 'cutlery' | 'dash' | 'deadline' | 'document-archive' | 'document-broken' | 'document-closed' | 'document-empty' | 'document-excel' | 'document-information' | 'document-minus' | 'document-pdf' | 'document-plus' | 'document-preview' | 'document-saved' | 'document-unknown' | 'document-word' | 'document' | 'dot' | 'double-chevron-left' | 'double-chevron-right' | 'download' | 'easy-language' | 'edit-document' | 'education' | 'equal' | 'excellence' | 'expand' | 'eye-close' | 'eye' | 'facebook' | 'family' | 'filter-funnel' | 'filter-sliders' | 'flag' | 'folder-opened' | 'folder-search' | 'folder-special-opened' | 'folder-special' | 'folder' | 'food' | 'forward' | 'fridge' | 'globe' | 'golf' | 'grid-compact' | 'grid' | 'growth' | 'hand' | 'handshake' | 'hiking' | 'history' | 'home' | 'hospital' | 'image-broken' | 'image' | 'info' | 'interest' | 'language' | 'left-panel-close' | 'left-panel-open' | 'lightbulb' | 'link-broken' | 'link' | 'list' | 'loader' | 'lock-open' | 'lock' | 'login' | 'logout' | 'magnifier' | 'mail-open' | 'mail' | 'maintenance' | 'manage-drafts' | 'maximum-weight' | 'minus' | 'mobile-phone' | 'moneybag' | 'moon' | 'more' | 'narrow' | 'new-event' | 'new-topic' | 'notes' | 'one-bed' | 'overflow' | 'parallel' | 'pause' | 'pen' | 'phone-desktop' | 'pin-germany' | 'pin-location' | 'play' | 'player-contract' | 'player-expand' | 'player-subtitles' | 'plus-check' | 'plus-one-bed' | 'plus' | 'pool' | 'position-finder' | 'presentation' | 'prevention-check' | 'prevention' | 'print' | 'prioritize' | 'psycho-gastroenterology' | 'public-building' | 'question-mark' | 'reply' | 'research' | 'restore' | 'rotation' | 'save' | 'scale' | 'select-all' | 'send' | 'server' | 'settings' | 'share' | 'shopping-cart' | 'shower' | 'shrink' | 'shuttle' | 'sign-language' | 'smoke-free' | 'sort-arrows-down' | 'sort-arrows-up' | 'sort-arrows' | 'sort' | 'sound-no' | 'sound-off' | 'sound-on' | 'special-plus' | 'special-tasks' | 'speech-bubble-DE' | 'stamp' | 'star-full' | 'star-half' | 'star' | 'statistics' | 'sun' | 'table' | 'talks' | 'telephone' | 'tennis' | 'terrace' | 'theater' | 'thumb-up' | 'tiles' | 'towel' | 'town-center' | 'trash' | 'tree' | 'turn' | 'tv' | 'twitter-x' | 'two-bed' | 'unselect-all' | 'upload' | 'user-portal' | 'user' | 'users' | 'vegan' | 'wheelchair' | 'wide-and-narrow' | 'width' | 'wifi' | 'worklifebalance' | 'workplace' | 'youtube' | 'zip';

type PlacementType = 'top' | 'right' | 'left' | 'bottom' | 'top-start' | 'right-start' | 'left-start' | 'bottom-start' | 'top-end' | 'right-end' | 'left-end' | 'bottom-end';
declare class TooltipComponent implements OnInit, OnDestroy, OnChanges {
    private elRef;
    private renderer;
    readonly placement: _angular_core.InputSignal<PlacementType>;
    readonly tooltip: _angular_core.InputSignal<string>;
    readonly dynamic: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private titleText;
    private tooltipElement;
    private toolTipOptions;
    private showTooltip;
    private hideTooltip;
    private title;
    constructor();
    protected get tooltipText(): string;
    /** @internal */
    ngOnInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    private setup;
    private createTooltipElement;
    private mouseHandler;
    private bindEvents;
    private unbindEvents;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TooltipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TooltipComponent, "[drv-tooltip]", never, { "placement": { "alias": "placement"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "dynamic": { "alias": "dynamic"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class IconComponent implements OnInit, OnChanges {
    private configService;
    readonly type: _angular_core.InputSignal<IconType>;
    readonly label: _angular_core.InputSignal<string>;
    readonly size: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly ariaHidden: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tooltip: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly tooltipPosition: _angular_core.InputSignal<PlacementType>;
    protected svgSrc: string;
    protected iconSpritePath: string;
    constructor();
    protected get xLink(): string;
    protected classNames: string;
    protected get sizeInRem(): number;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnChanges(): void;
    private setSource;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconComponent, "drv-icon", never, { "type": { "alias": "type"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaHidden": { "alias": "ariaHidden"; "required": false; "isSignal": true; }; "tooltip": { "alias": "tooltip"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class LabelComponent implements OnInit {
    private elementRef;
    private configService;
    readonly id: _angular_core.InputSignal<string>;
    readonly required: _angular_core.ModelSignal<unknown>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHidden: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly removeHost: _angular_core.InputSignalWithTransform<boolean, unknown>;
    constructor();
    protected get combinedClasses(): string;
    /** @internal */
    ngOnInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LabelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LabelComponent, "drv-label", never, { "id": { "alias": "for"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHidden": { "alias": "visuallyHidden"; "required": false; "isSignal": true; }; "removeHost": { "alias": "removeHost"; "required": false; "isSignal": true; }; }, { "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, ["*"], true, never>;
}

declare class ListComponent implements OnInit {
    private elementRef;
    readonly items: _angular_core.InputSignal<string[]>;
    readonly type: _angular_core.InputSignal<"check" | "ol" | "ul">;
    readonly removeHost: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected trackByFn: (index: number) => number;
    /** @internal */
    ngOnInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ListComponent, "drv-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "removeHost": { "alias": "removeHost"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type OnChangeFunction = (v: unknown) => void;
type OnTouchedFunction = (v: boolean | FocusEvent) => void;
declare class ValueAccessorDirective<T> implements ControlValueAccessor, OnDestroy {
    private onChange;
    private onTouched;
    private valueSubject;
    private disabledSubject;
    private host;
    readonly value: rxjs.Observable<T>;
    readonly disabled: rxjs.Observable<boolean>;
    onBlur(event: FocusEvent): void;
    ngOnDestroy(): void;
    valueChange(v: T): void;
    touchedChange(v: boolean): void;
    writeValue(obj: T): void;
    registerOnChange(fn: OnChangeFunction): void;
    registerOnTouched(fn: OnTouchedFunction): void;
    setDisabledState(isDisabled: boolean): void;
    setHost(host: unknown): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ValueAccessorDirective<any>, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ValueAccessorDirective<any>, never, never, {}, {}, never, never, true, never>;
}

/**
 * @deprecated The type `BackgroundUI` will be removed in the next major version.
 * Use `BackgroundUILightColor`, `BackgroundUIDarkColor`, or `BackgroundUILightDark` instead.
 */
type BackgroundUI = 'light' | 'dark' | 'color';
type BackgroundUILightColor = 'light' | 'color';
type BackgroundUILightDark = 'light' | 'dark';

type PortalContentType = TemplatePortal | ComponentPortal<unknown>;

interface AriaAttributes$2 {
    [key: string]: unknown;
    describedby?: string;
    labelledby?: string;
    controls?: string;
    invalid?: boolean | 'true' | 'false';
    pressed?: boolean | 'true' | 'false';
}

interface FormItemMessage {
    message: string;
    type?: string;
}
declare class FormitemComponent {
    readonly id: _angular_core.InputSignal<string>;
    readonly cssClass: _angular_core.InputSignal<string>;
    readonly hasError: _angular_core.ModelSignal<boolean>;
    readonly errorText: _angular_core.ModelSignal<FormItemMessage[]>;
    readonly errorPrefix: _angular_core.InputSignal<string>;
    readonly hasInfo: _angular_core.ModelSignal<boolean>;
    readonly infoText: _angular_core.ModelSignal<FormItemMessage[]>;
    readonly infoPrefix: _angular_core.InputSignal<string>;
    readonly hasWarning: _angular_core.ModelSignal<boolean>;
    readonly warningText: _angular_core.ModelSignal<FormItemMessage[]>;
    readonly warningPrefix: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly collapseMessages: _angular_core.ModelSignal<boolean>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUI>;
    readonly announceChanges: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected externalId: string;
    protected trackByFn: (index: number) => number;
    protected get containerCssClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormitemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormitemComponent, "drv-formitem", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "cssClass": { "alias": "cssClass"; "required": false; "isSignal": true; }; "hasError": { "alias": "hasError"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; "errorPrefix": { "alias": "errorPrefix"; "required": false; "isSignal": true; }; "hasInfo": { "alias": "hasInfo"; "required": false; "isSignal": true; }; "infoText": { "alias": "infoText"; "required": false; "isSignal": true; }; "infoPrefix": { "alias": "infoPrefix"; "required": false; "isSignal": true; }; "hasWarning": { "alias": "hasWarning"; "required": false; "isSignal": true; }; "warningText": { "alias": "warningText"; "required": false; "isSignal": true; }; "warningPrefix": { "alias": "warningPrefix"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "collapseMessages": { "alias": "collapseMessages"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "announceChanges": { "alias": "announceChanges"; "required": false; "isSignal": true; }; }, { "hasError": "hasErrorChange"; "errorText": "errorTextChange"; "hasInfo": "hasInfoChange"; "infoText": "infoTextChange"; "hasWarning": "hasWarningChange"; "warningText": "warningTextChange"; "disabled": "disabledChange"; "collapseMessages": "collapseMessagesChange"; }, never, ["*"], true, never>;
}

declare class OptionGroupComponent implements OnChanges {
    private dropdownService;
    readonly options: _angular_core.InputSignal<DrvDropdownOption[]>;
    readonly label: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    private parent;
    constructor();
    ngOnChanges(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OptionGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OptionGroupComponent, "drv-optiongroup", never, { "options": { "alias": "options"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type DropdownAriaAttributes = AriaAttributes$2 & {
    expanded?: boolean | 'true' | 'false';
    activedescendant?: string;
    required?: boolean | 'true' | 'false';
};
interface DrvDropdownOption {
    label?: string;
    value?: string;
    disabled?: boolean;
}
interface DrvDropdownOptionTemplate extends DrvDropdownOption {
    selected?: boolean;
    hasFocus?: boolean;
}
interface DrvDropdownOptionGroupTemplate {
    groupLabel?: string;
    disabled?: boolean;
    options: number[];
}
declare class DropdownComponent extends FormitemComponent implements OnChanges, OnDestroy {
    private configService;
    private deviceService;
    private dropdownService;
    private cdRef;
    readonly valueAccessor: ValueAccessorDirective<DrvDropdownOption[]>;
    readonly options: _angular_core.InputSignal<DrvDropdownOption[]>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly selectedText: _angular_core.InputSignal<string>;
    readonly selectedSuffixText: _angular_core.InputSignal<string>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<unknown>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    readonly closed: _angular_core.OutputEmitterRef<null>;
    readonly setValueOnBlur: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    readonly selectElement: _angular_core.Signal<ElementRef<any>>;
    readonly list: _angular_core.Signal<ElementRef<any>>;
    readonly listbox: _angular_core.Signal<ElementRef<any>>;
    readonly container: _angular_core.Signal<ElementRef<any>>;
    readonly listitems: _angular_core.Signal<readonly ElementRef<any>[]>;
    readonly templateRef: _angular_core.Signal<TemplateRef<any>>;
    protected groups: Set<OptionGroupComponent>;
    protected templateOptions: DrvDropdownOptionTemplate[];
    protected templateGroups: DrvDropdownOptionGroupTemplate[];
    protected isOpen: boolean;
    protected trackByFn: (index: number) => number;
    private innerValue;
    private typeAheadTerm;
    private tyepAheadTimeout;
    private subscription;
    constructor();
    protected get hostRole(): string | null;
    protected get containerCssClasses(): string;
    protected get triggerButtonAriaAttributes(): DropdownAriaAttributes;
    protected get triggerButtonCssClasses(): string[];
    protected get triggerButtonText(): string;
    protected get activeDescendant(): string | null;
    protected get activeDescendantCount(): number;
    protected get isMobile(): boolean;
    get value(): DrvDropdownOption[];
    set value(value: DrvDropdownOption[]);
    protected handleWindowClick(target: Element): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    protected selectFocusout(event: any): void;
    protected buttonFocusout(event: any): void;
    protected buttonClickHandler(): void;
    protected select(index: number): void;
    protected setValueFromSelect(event: Event): void;
    protected keydownButton(event: KeyboardEvent): void;
    protected toggle(isOpen?: boolean, focusInput?: boolean): void;
    private selectFromTypeAhead;
    private selectOption;
    private getNeighbourIndex;
    private focusOption;
    private setValue;
    private optionMapper;
    private buildOptions;
    private calculatePosition;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DropdownComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DropdownComponent, "drv-dropdown", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "selectedText": { "alias": "selectedText"; "required": false; "isSignal": true; }; "selectedSuffixText": { "alias": "selectedSuffixText"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "setValueOnBlur": { "alias": "setValueOnBlur"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; "closed": "closed"; }, ["templateRef"], never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface SetGroup {
    id: string;
    group: OptionGroupComponent;
}
declare class DropdownService {
    private group;
    readonly group$: rxjs.Observable<SetGroup>;
    setGroup(obj: SetGroup): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DropdownService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<DropdownService>;
}

type ThrottledFunction<T extends unknown[]> = (...args: T) => void;

interface DrvComboboxOption {
    value: string;
}
type ComboboxAutoCompleteOptions = 'list' | 'both' | 'none';
interface ComboBoxAriaAttributes extends AriaAttributes$2 {
    [key: string]: unknown;
    expanded?: boolean | 'true' | 'false';
    hasPopUp?: 'listbox' | 'menu' | 'tree' | 'grid' | 'dialog';
    autocomplete?: ComboboxAutoCompleteOptions;
    controls?: string;
    required?: boolean | 'true' | 'false';
}
interface ComboBoxOptionTemplate extends DrvComboboxOption {
    selected?: boolean;
    hidden?: boolean;
}
declare class ComboboxComponent extends FormitemComponent implements OnChanges {
    private configService;
    private deviceService;
    readonly valueAccessor: ValueAccessorDirective<string>;
    readonly options: _angular_core.InputSignal<DrvComboboxOption[]>;
    readonly label: _angular_core.ModelSignal<string>;
    readonly id: _angular_core.ModelSignal<string>;
    readonly placeholder: _angular_core.ModelSignal<string>;
    readonly selectedText: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<unknown>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.ModelSignal<boolean>;
    readonly hideToggleButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly noResultsText: _angular_core.InputSignal<string>;
    readonly toggleButtonLabel: _angular_core.InputSignal<string>;
    readonly autoComplete: _angular_core.InputSignal<ComboboxAutoCompleteOptions>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    readonly closed: _angular_core.OutputEmitterRef<null>;
    readonly open: _angular_core.OutputEmitterRef<null>;
    readonly input: _angular_core.Signal<ElementRef<HTMLInputElement>>;
    readonly listbox: _angular_core.Signal<ElementRef<HTMLElement>>;
    readonly container: _angular_core.Signal<ElementRef<HTMLElement>>;
    readonly listitems: _angular_core.Signal<readonly ElementRef<any>[]>;
    protected isOpen: boolean;
    protected templateOptions: ComboBoxOptionTemplate[];
    protected trackByFn: (index: number) => number;
    protected keydownInput: ThrottledFunction<unknown[]>;
    protected filterOptions: ThrottledFunction<unknown[]>;
    private innerValue?;
    constructor();
    protected get hostRole(): string | null;
    protected get containerCssClasses(): string;
    protected get inputAriaAttributes(): ComboBoxAriaAttributes;
    protected get cssBgClass(): string;
    protected get activeDescendant(): string;
    protected get isMobile(): boolean;
    protected get resultCount(): number;
    protected get noResults(): boolean;
    protected get showButton(): boolean;
    get value(): string;
    set value(value: string);
    protected handleWindowClick(target: HTMLElement): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    protected buttonClickHandler(): void;
    protected clickInput(): void;
    protected selectOption(current: ComboBoxOptionTemplate, next: ComboBoxOptionTemplate): void;
    protected markSearchTerm(text: string): string;
    protected blurHandler(event: FocusEvent): void;
    protected select(event: MouseEvent, index: number): void;
    protected toggle(isOpen?: boolean): void;
    protected setValue(): void;
    protected setValueFromSelect(event: Event): void;
    private filterList;
    private optionMapper;
    private calculatePosition;
    private keydownInputUnthrottled;
    private filterOptionsUnthrottled;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ComboboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ComboboxComponent, "drv-combobox", never, { "options": { "alias": "options"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "id": { "alias": "id"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "selectedText": { "alias": "selectedText"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "hideToggleButton": { "alias": "hideToggleButton"; "required": false; "isSignal": true; }; "noResultsText": { "alias": "noResultsText"; "required": false; "isSignal": true; }; "toggleButtonLabel": { "alias": "toggleButtonLabel"; "required": false; "isSignal": true; }; "autoComplete": { "alias": "autoComplete"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; }, { "label": "labelChange"; "id": "idChange"; "placeholder": "placeholderChange"; "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; "visuallyHiddenLabel": "visuallyHiddenLabelChange"; "closed": "closed"; "open": "open"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

type PictogramsType = 'alignment' | 'application' | 'benefits' | 'briefcase' | 'calculator' | 'card-reader' | 'code' | 'coffee' | 'communication' | 'customer-king' | 'date' | 'devices' | 'digitizing' | 'doctor' | 'edit-profile' | 'end-to-end' | 'feedback' | 'finances' | 'fingerprint' | 'fitness-tracking' | 'form' | 'heartbeat' | 'id-card' | 'info' | 'insured' | 'laptop' | 'leaf' | 'legislation' | 'list' | 'lock' | 'medical-research' | 'messaging' | 'pensioner' | 'people' | 'perfomance' | 'presentation-slides' | 'press' | 'print' | 'progress' | 'rocket' | 'search' | 'secure-mail' | 'status' | 'strategy' | 'table' | 'team' | 'template-sidenav' | 'template-split' | 'text' | 'union' | 'upload' | 'workshop';

declare class PictogramComponent implements OnInit, OnChanges {
    private configService;
    readonly label: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<PictogramsType>;
    readonly size: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly ariaHidden: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected svgSrc: string;
    protected pictogramSpritePath: string;
    constructor();
    protected get xLink(): string;
    protected classNames: string;
    protected get sizeInRem(): number;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnChanges(): void;
    private setSource;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PictogramComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PictogramComponent, "drv-pictogram", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": true; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "ariaHidden": { "alias": "ariaHidden"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface AriaAttributes$1 {
    [key: string]: string | number | undefined;
    label?: string;
    valuetext?: string;
    valuemax: number;
    valuenow: number;
}
declare class ProgressBarComponent {
    readonly value: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly max: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly ariaLabel: _angular_core.InputSignal<string>;
    readonly ariaValuetext: _angular_core.InputSignal<string>;
    readonly variant: _angular_core.InputSignal<"default" | "sticky">;
    protected isNaN: typeof Number.isNaN;
    get inputAriaAttributes(): AriaAttributes$1;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressBarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressBarComponent, "drv-progressbar", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "ariaValuetext": { "alias": "ariaValuetext"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class DetailsComponent {
    readonly isOpen: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly title: _angular_core.InputSignal<string>;
    readonly toggled: _angular_core.OutputEmitterRef<boolean>;
    protected toggleHandler(e: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DetailsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DetailsComponent, "drv-details", never, { "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": true; "isSignal": true; }; }, { "toggled": "toggled"; }, never, ["*"], true, never>;
}

declare class AccordionItemComponent implements OnInit, AfterViewInit, OnDestroy {
    isOpen: boolean;
    private router;
    private activatedRoute;
    private changeDetector;
    /** @internal */
    readonly detailsElement: _angular_core.Signal<ElementRef<any>>;
    readonly message: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly iconType: _angular_core.InputSignal<"status-processing" | "status-success" | "status-warning">;
    readonly itemId: _angular_core.InputSignal<string>;
    toggled: EventEmitter<AccordionItemComponent>;
    private routerSubscription;
    protected get open(): boolean | null;
    /** @internal */
    markForCheck(): void;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    /**
     * @param {string} hash URL-Hash
     * @internal
     */
    toggleFromHash(hash: string): void;
    protected emitToggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AccordionItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AccordionItemComponent, "drv-accordionitem", never, { "isOpen": { "alias": "isOpen"; "required": false; }; "message": { "alias": "message"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "iconType": { "alias": "iconType"; "required": false; "isSignal": true; }; "itemId": { "alias": "itemId"; "required": false; "isSignal": true; }; }, { "toggled": "toggled"; }, never, ["*"], true, never>;
    static ngAcceptInputType_isOpen: unknown;
}

type AriaPressedType = boolean | 'mixed';
interface AriaAttributes {
    [key: string]: unknown;
    hasPopUp?: boolean;
    describedBy?: string;
    labelledBy?: string;
    label?: string;
    expanded?: boolean;
    pressed?: AriaPressedType;
    controls?: string;
}
type IconPositionType = 'left' | 'right';
type IconOnlyType = 'only' | 'only-xlg' | 'only-lg' | 'only-md' | 'only-sm';
type FullSizeOptionType = 'full' | 'full-xlg' | 'full-lg' | 'full-md' | 'full-sm';
type ButtonTypeType = 'button' | 'submit' | 'anchor' | 'input' | 'reset';
type ButtonKindType = 'primary' | 'secondary' | 'tertiary';
type ClickFunction = (event: MouseEvent | unknown) => void;
declare class ButtonComponent implements OnDestroy, OnInit, OnChanges, AfterViewInit {
    tooltip: boolean;
    private router;
    private renderer;
    private configService;
    readonly cssClass: _angular_core.ModelSignal<string>;
    readonly type: _angular_core.InputSignal<ButtonTypeType>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    readonly kind: _angular_core.ModelSignal<ButtonKindType>;
    readonly href: _angular_core.InputSignal<string>;
    readonly target: _angular_core.InputSignal<"_self" | "_blank" | "_parent" | "_top">;
    readonly route: _angular_core.InputSignal<string[] | Route[]>;
    readonly routeExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly backgroundUI: _angular_core.ModelSignal<BackgroundUI>;
    readonly iconPosition: _angular_core.ModelSignal<IconPositionType>;
    readonly iconOnly: _angular_core.InputSignal<IconOnlyType>;
    readonly iconType: _angular_core.InputSignal<IconType>;
    readonly isLoading: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fullSizeOption: _angular_core.InputSignal<FullSizeOptionType>;
    readonly iconCssClass: _angular_core.InputSignal<string>;
    readonly tooltipPosition: _angular_core.InputSignal<PlacementType>;
    readonly dataAttributes: _angular_core.InputSignal<Record<string, unknown>>;
    readonly ariaAttributes: _angular_core.ModelSignal<AriaAttributes>;
    readonly keyboardShortcut: _angular_core.InputSignal<string>;
    readonly keyboardShortcutText: _angular_core.InputSignal<string>;
    readonly miniButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly buttonClick: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly hostClass: _angular_core.InputSignal<string>;
    /** @internal */
    readonly input: _angular_core.Signal<ElementRef<any>>;
    /** @internal */
    readonly buttonTemplate: _angular_core.Signal<TemplateRef<unknown>>;
    readonly popovertarget: _angular_core.InputSignal<string>;
    readonly popovertargetaction: _angular_core.InputSignal<string>;
    private tooltipElement;
    private toolTipOptions;
    private showTooltip;
    private hideTooltip;
    private showKeyboardshortcutTooltip;
    constructor();
    protected readonly combinedClasses: _angular_core.Signal<string>;
    protected get iconClassNames(): string;
    protected get getHref(): string;
    protected get keyboardShortcutTextHint(): string;
    readonly click: _angular_core.InputSignal<ClickFunction>;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    /**
     * @param {MouseEvent} event MouseEvent
     * @internal
     */
    onClickHandler(event: MouseEvent): void;
    private createTooltipElement;
    private mouseHandler;
    private bindEvents;
    private unbindEvents;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonComponent, "drv-button", never, { "tooltip": { "alias": "tooltip"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "kind": { "alias": "kind"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "route": { "alias": "route"; "required": false; "isSignal": true; }; "routeExtras": { "alias": "routeExtras"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "iconPosition": { "alias": "iconPosition"; "required": false; "isSignal": true; }; "iconOnly": { "alias": "iconOnly"; "required": false; "isSignal": true; }; "iconType": { "alias": "iconType"; "required": false; "isSignal": true; }; "isLoading": { "alias": "isLoading"; "required": false; "isSignal": true; }; "fullSizeOption": { "alias": "fullSizeOption"; "required": false; "isSignal": true; }; "iconCssClass": { "alias": "iconCssClass"; "required": false; "isSignal": true; }; "tooltipPosition": { "alias": "tooltipPosition"; "required": false; "isSignal": true; }; "dataAttributes": { "alias": "dataAttributes"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "keyboardShortcut": { "alias": "keyboardShortcut"; "required": false; "isSignal": true; }; "keyboardShortcutText": { "alias": "keyboardShortcutText"; "required": false; "isSignal": true; }; "miniButton": { "alias": "miniButton"; "required": false; "isSignal": true; }; "hostClass": { "alias": "hostClass"; "required": false; "isSignal": true; }; "popovertarget": { "alias": "popovertarget"; "required": false; "isSignal": true; }; "popovertargetaction": { "alias": "popovertargetaction"; "required": false; "isSignal": true; }; "click": { "alias": "click"; "required": false; "isSignal": true; }; }, { "cssClass": "cssClassChange"; "kind": "kindChange"; "backgroundUI": "backgroundUIChange"; "iconPosition": "iconPositionChange"; "ariaAttributes": "ariaAttributesChange"; "buttonClick": "buttonClick"; }, never, never, true, never>;
    static ngAcceptInputType_tooltip: unknown;
}

declare class AccordionComponent implements AfterViewInit {
    multiselectable: boolean;
    showToggleAllButton: boolean;
    readonly toggleAllTextOpen: _angular_core.InputSignal<string>;
    readonly toggleAllTextClose: _angular_core.InputSignal<string>;
    readonly headline: _angular_core.InputSignal<string>;
    readonly items: _angular_core.Signal<readonly AccordionItemComponent[]>;
    private expandedItems;
    protected get buttonAriaAttributes(): AriaAttributes;
    ngAfterViewInit(): void;
    protected toggleAll(): void;
    private closeOthers;
    private initWatchers;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AccordionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AccordionComponent, "drv-accordion", never, { "multiselectable": { "alias": "multiselectable"; "required": false; }; "showToggleAllButton": { "alias": "showToggleAllButton"; "required": false; }; "toggleAllTextOpen": { "alias": "toggleAllTextOpen"; "required": false; "isSignal": true; }; "toggleAllTextClose": { "alias": "toggleAllTextClose"; "required": false; "isSignal": true; }; "headline": { "alias": "headline"; "required": false; "isSignal": true; }; }, {}, ["items"], ["[headline]", "*"], true, never>;
    static ngAcceptInputType_multiselectable: unknown;
    static ngAcceptInputType_showToggleAllButton: unknown;
}

type ButtonBarVariant = 'actions' | 'narrow' | 'navigation' | 'navigation-no-line' | '';
type ButtonBarPlacing = 'start' | 'center' | 'end' | 'space-between' | 'space-between-first' | 'space-between-last';
type ButtonBarLayoutMobile = 'inline' | 'block' | 'wrap';
declare class ButtonbarComponent {
    readonly variant: _angular_core.InputSignal<ButtonBarVariant>;
    readonly placing: _angular_core.InputSignal<ButtonBarPlacing>;
    readonly layoutMobile: _angular_core.InputSignal<ButtonBarLayoutMobile>;
    readonly wrap: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected get containerCssClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ButtonbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ButtonbarComponent, "drv-buttonbar", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "placing": { "alias": "placing"; "required": false; "isSignal": true; }; "layoutMobile": { "alias": "layoutMobile"; "required": false; "isSignal": true; }; "wrap": { "alias": "wrap"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface CheckboxChange {
    source: CheckboxComponent;
    value: string | number | unknown;
}
declare class CheckboxComponent implements OnChanges, OnInit, OnDestroy {
    private parent;
    private inputGroupService;
    readonly changeDetector: ChangeDetectorRef;
    readonly elementRef: ElementRef<any>;
    readonly valueAccessor: ValueAccessorDirective<unknown>;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.ModelSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly value: _angular_core.InputSignal<string>;
    readonly labelHidden: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly backgroundUI: _angular_core.ModelSignal<BackgroundUI>;
    readonly ariaAttributes: _angular_core.ModelSignal<AriaAttributes$2>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    readonly checkboxChange: _angular_core.OutputEmitterRef<CheckboxChange>;
    /** @internal */
    readonly rendered: _angular_core.OutputEmitterRef<void>;
    /** @internal */
    readonly enabled: EventEmitter<CheckboxComponent>;
    /** @internal */
    externalId: string;
    private innerValue?;
    private labelClicked;
    private destroyed$;
    constructor();
    protected get title(): string;
    protected get containerCssClasses(): string;
    get labelClasses(): string;
    set checked(value: boolean);
    get model(): unknown;
    set model(value: unknown);
    protected onFocusout(event: FocusEvent): void;
    /** @internal */
    ngOnInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    protected focusHandler({ target }: {
        target: any;
    }): void;
    protected labelClick(): void;
    private setAriaAttributes;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CheckboxComponent, "drv-checkbox", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "labelHidden": { "alias": "labelHidden"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; }; }, { "name": "nameChange"; "disabled": "disabledChange"; "required": "requiredChange"; "backgroundUI": "backgroundUIChange"; "ariaAttributes": "ariaAttributesChange"; "checkboxChange": "checkboxChange"; "rendered": "rendered"; "enabled": "enabled"; }, never, ["*"], true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

type DisableDatesFn = (date: Date) => boolean;
declare class DatepickerComponent extends FormitemComponent implements AfterViewInit, OnInit {
    readonly valueAccessor: ValueAccessorDirective<string>;
    private configService;
    private document;
    private elementRef;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<unknown>;
    readonly inline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly appointments: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly allowInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rangeMode: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly label: _angular_core.InputSignal<string>;
    readonly minDate: _angular_core.InputSignal<string | Date>;
    readonly maxDate: _angular_core.InputSignal<string | Date>;
    readonly dateFormat: _angular_core.InputSignal<string>;
    readonly disabledDates: _angular_core.InputSignal<DisableDatesFn>;
    readonly nextMonthButtonLabel: _angular_core.InputSignal<string>;
    readonly prevMonthButtonLabel: _angular_core.InputSignal<string>;
    readonly collapseMessages: _angular_core.ModelSignal<boolean>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly locale: _angular_core.InputSignal<string>;
    /** content of the toggletip, when to show */
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    /** @internal */
    readonly input: _angular_core.Signal<ElementRef<any>>;
    /** @internal */
    readonly cally: _angular_core.Signal<ElementRef<any>>;
    protected get containerCssClasses(): string;
    protected maskOptions?: MaskitoOptions;
    private innerValue?;
    private callyFormat;
    private rangeSeperator;
    protected htmlLocale: string;
    protected isOpen: boolean;
    protected callyValue?: string;
    protected heading: string;
    constructor();
    protected get cssInputClass(): string[];
    protected get describedBy(): string | null;
    protected get max(): string;
    protected get min(): string;
    protected onFocusout(event: FocusEvent): void;
    protected onWindowClick(event: FocusEvent): void;
    protected onFocusin(target: Element): void;
    protected keydownHandler(e: KeyboardEvent): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnInit(): void;
    protected inputChange({ target }: {
        target: any;
    }): void;
    protected callyChange(e: Event): void;
    protected callyFocusday(e: Event): void;
    private setCallyValue;
    private calculatePosition;
    private convertDate;
    private updateTitle;
    private ensureValidLocale;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DatepickerComponent, "drv-datepicker", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "appointments": { "alias": "appointments"; "required": false; "isSignal": true; }; "allowInput": { "alias": "allowInput"; "required": false; "isSignal": true; }; "rangeMode": { "alias": "rangeMode"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; "dateFormat": { "alias": "dateFormat"; "required": false; "isSignal": true; }; "disabledDates": { "alias": "disabledDates"; "required": false; "isSignal": true; }; "nextMonthButtonLabel": { "alias": "nextMonthButtonLabel"; "required": false; "isSignal": true; }; "prevMonthButtonLabel": { "alias": "prevMonthButtonLabel"; "required": false; "isSignal": true; }; "collapseMessages": { "alias": "collapseMessages"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "locale": { "alias": "locale"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "collapseMessages": "collapseMessagesChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

type MonthSelectorType = 'static' | 'dropdown';
interface DateRangeLimit<D = DateOption> {
    from: D;
    to: D;
}
type DateOption = Date | string | number;
type DateLimit<D = DateOption> = D | DateRangeLimit<D> | ((date: Date) => boolean);
declare class DatepickerLegacyComponent extends FormitemComponent implements AfterViewInit, OnChanges, OnDestroy {
    private configService;
    readonly valueAccessor: ValueAccessorDirective<string>;
    private elementRef;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<unknown>;
    readonly native: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly appointments: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly allowInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly rangeMode: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pickrLocale: _angular_core.InputSignal<any>;
    readonly label: _angular_core.InputSignal<string>;
    readonly minDate: _angular_core.InputSignal<string | Date>;
    readonly maxDate: _angular_core.InputSignal<string | Date>;
    readonly dateFormat: _angular_core.InputSignal<string>;
    readonly altFormat: _angular_core.InputSignal<string>;
    readonly altInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabledDates: _angular_core.InputSignal<DateLimit<DateOption>[]>;
    readonly nextMonthButtonLabel: _angular_core.InputSignal<string>;
    readonly prevMonthButtonLabel: _angular_core.InputSignal<string>;
    readonly collapseMessages: _angular_core.ModelSignal<boolean>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly monthSelectorType: _angular_core.InputSignal<MonthSelectorType>;
    /** content of the toggletip, when to show */
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    readonly inlineHolder: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    protected get containerCssClasses(): string;
    protected iconSpritePath: string;
    private instance;
    private changeableOptions;
    private innerValue?;
    constructor();
    protected get cssInputClass(): string[];
    protected get describedBy(): string | null;
    protected onFocusout(event: FocusEvent): void;
    /** @internal */
    ngAfterViewInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    protected setDisabledState(isDisabled: boolean): void;
    protected inputChange({ target }: {
        target: any;
    }): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DatepickerLegacyComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DatepickerLegacyComponent, "drv-datepicker-legacy", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "native": { "alias": "native"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "appointments": { "alias": "appointments"; "required": false; "isSignal": true; }; "allowInput": { "alias": "allowInput"; "required": false; "isSignal": true; }; "rangeMode": { "alias": "rangeMode"; "required": false; "isSignal": true; }; "pickrLocale": { "alias": "pickrLocale"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; "dateFormat": { "alias": "dateFormat"; "required": false; "isSignal": true; }; "altFormat": { "alias": "altFormat"; "required": false; "isSignal": true; }; "altInput": { "alias": "altInput"; "required": false; "isSignal": true; }; "disabledDates": { "alias": "disabledDates"; "required": false; "isSignal": true; }; "nextMonthButtonLabel": { "alias": "nextMonthButtonLabel"; "required": false; "isSignal": true; }; "prevMonthButtonLabel": { "alias": "prevMonthButtonLabel"; "required": false; "isSignal": true; }; "collapseMessages": { "alias": "collapseMessages"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "monthSelectorType": { "alias": "monthSelectorType"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "collapseMessages": "collapseMessagesChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

declare class TimePickerComponent extends FormitemComponent implements AfterViewInit, OnChanges, OnDestroy {
    private configService;
    private elementRef;
    readonly valueAccessor: ValueAccessorDirective<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly native: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly inline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pickrLocale: _angular_core.InputSignal<any>;
    readonly label: _angular_core.InputSignal<string>;
    readonly nextMonthButtonLabel: _angular_core.InputSignal<string>;
    readonly prevMonthButtonLabel: _angular_core.InputSignal<string>;
    readonly minuteIncrement: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    readonly inlineHolder: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    protected get containerCssClasses(): string;
    protected iconSpritePath: string;
    private innerValue;
    private instance;
    private changeableOptions;
    constructor();
    protected get cssClasses(): string[];
    protected get describedBy(): string | null;
    protected onFocusout(event: FocusEvent): void;
    /** @internal */
    ngAfterViewInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    protected onChange({ target }: {
        target: any;
    }): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TimePickerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TimePickerComponent, "drv-timepicker", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "native": { "alias": "native"; "required": false; "isSignal": true; }; "inline": { "alias": "inline"; "required": false; "isSignal": true; }; "pickrLocale": { "alias": "pickrLocale"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "nextMonthButtonLabel": { "alias": "nextMonthButtonLabel"; "required": false; "isSignal": true; }; "prevMonthButtonLabel": { "alias": "prevMonthButtonLabel"; "required": false; "isSignal": true; }; "minuteIncrement": { "alias": "minuteIncrement"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface SelectBoxOption {
    label: string;
    value: string;
    disabled?: boolean;
}
declare class SelectBoxComponent extends FormitemComponent {
    readonly valueAccessor: ValueAccessorDirective<string | number | boolean>;
    private configService;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly options: _angular_core.InputSignal<SelectBoxOption[]>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    protected trackByFn: (index: number) => number;
    private innerValue;
    constructor();
    protected get containerCssClasses(): string;
    protected get inputAriaAttributes(): AriaAttributes$2;
    protected get cssElementClass(): string;
    get value(): number | boolean | string;
    set value(value: number | boolean | string);
    protectedonFocusout(event: FocusEvent): void;
    protected entrySelected(value: number | boolean | string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SelectBoxComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SelectBoxComponent, "drv-select", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface FilterOptions {
    label: string;
    value: string;
    selected?: boolean;
    disabled?: boolean;
    hasFocus?: boolean;
}
declare class FilterComponent implements OnInit, OnChanges {
    private deviceService;
    readonly valueAccessor: ValueAccessorDirective<string[]>;
    readonly id: _angular_core.InputSignal<string>;
    readonly buttonText: _angular_core.ModelSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly labelVisible: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUI>;
    readonly btnResetText: _angular_core.InputSignal<string>;
    readonly selectedText: _angular_core.InputSignal<string>;
    readonly selectedSuffixText: _angular_core.InputSignal<string>;
    readonly selectCount: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly options: _angular_core.InputSignal<FilterOptions[]>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showResetButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly setValueOnBlur: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closed: _angular_core.OutputEmitterRef<null>;
    readonly clear: _angular_core.OutputEmitterRef<null>;
    trigger: ElementRef | HTMLElement;
    readonly list: _angular_core.Signal<ElementRef<any>>;
    readonly container: _angular_core.Signal<ElementRef<any>>;
    readonly selectElement: _angular_core.Signal<ElementRef<any>>;
    readonly listitems: _angular_core.Signal<readonly ElementRef<any>[]>;
    readonly resetButton: _angular_core.Signal<ButtonComponent>;
    protected externalId: string;
    protected hostClass: string;
    protected isOpen: boolean;
    protected trackByFn: (index: number) => number;
    private innerValue?;
    private initialButtonText;
    constructor();
    protected get hostRole(): string | null;
    protected get labelClass(): string;
    protected get triggerButtonAriaAttributes(): AriaAttributes$2;
    protected get triggerButtonCssClasses(): string;
    protected get activeDescendant(): string;
    protected get selectedOptionCount(): number;
    protected get activeDescendantCount(): number;
    protected get isMobile(): boolean;
    get value(): string[];
    set value(value: string[]);
    protected handleWindowClick(target: MouseEvent): void;
    /** @internal */
    ngOnInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    protected buttonClickHandler(): void;
    protected select(index: number): void;
    protected setValueFromSelect(event: Event): void;
    protected clearValue(): void;
    protected buttonFocusout(event: FocusEvent): void;
    protected resetButtonBlurHandler(event: FocusEvent): void;
    protected keydownButton(event: KeyboardEvent): void;
    protected keydownResetButton(event: KeyboardEvent): void;
    protected keydownButtonNoContent(event: KeyboardEvent): void;
    protected toggle(isOpen?: boolean, focusInput?: boolean): void;
    private getNeighbourIndex;
    protected noContentFocusOut(event: FocusEvent): void;
    private focusOption;
    private selectOption;
    private setValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FilterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FilterComponent, "drv-filter", never, { "id": { "alias": "id"; "required": true; "isSignal": true; }; "buttonText": { "alias": "buttonText"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "labelVisible": { "alias": "labelVisible"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "btnResetText": { "alias": "btnResetText"; "required": false; "isSignal": true; }; "selectedText": { "alias": "selectedText"; "required": false; "isSignal": true; }; "selectedSuffixText": { "alias": "selectedSuffixText"; "required": false; "isSignal": true; }; "selectCount": { "alias": "selectCount"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "showResetButton": { "alias": "showResetButton"; "required": false; "isSignal": true; }; "setValueOnBlur": { "alias": "setValueOnBlur"; "required": false; "isSignal": true; }; }, { "buttonText": "buttonTextChange"; "disabled": "disabledChange"; "closed": "closed"; "clear": "clear"; }, never, ["*"], true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface ColOptions {
    bleed?: 'left' | 'right' | 'both';
    nobleed?: 'left' | 'right' | 'both';
}
interface ColOptionsDefault extends ColOptions {
    offset?: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
    span: 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24;
}
interface ColOptionsSmall extends ColOptions {
    offset?: 0 | 1 | 2 | 3;
    span: 0 | 1 | 2 | 3 | 4;
}
declare class ColDirective {
    readonly sm: _angular_core.InputSignal<number | ColOptionsSmall>;
    readonly md: _angular_core.InputSignal<number | ColOptionsDefault>;
    readonly lg: _angular_core.InputSignal<number | ColOptionsDefault>;
    readonly xlg: _angular_core.InputSignal<number | ColOptionsDefault>;
    readonly max: _angular_core.InputSignal<number | ColOptionsDefault>;
    readonly noGutter: _angular_core.InputSignal<"" | "right" | "left" | "both">;
    readonly padding: _angular_core.InputSignal<boolean>;
    protected get combinedClassNames(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ColDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ColDirective, "[drv-col]", never, { "sm": { "alias": "sm"; "required": false; "isSignal": true; }; "md": { "alias": "md"; "required": false; "isSignal": true; }; "lg": { "alias": "lg"; "required": false; "isSignal": true; }; "xlg": { "alias": "xlg"; "required": false; "isSignal": true; }; "max": { "alias": "max"; "required": false; "isSignal": true; }; "noGutter": { "alias": "noGutter"; "required": false; "isSignal": true; }; "padding": { "alias": "padding"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class GridDirective {
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    readonly condensed: _angular_core.InputSignal<boolean>;
    readonly narrow: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<GridDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<GridDirective, "[drv-grid]", never, { "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "condensed": { "alias": "condensed"; "required": false; "isSignal": true; }; "narrow": { "alias": "narrow"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class RowDirective {
    readonly noGutter: _angular_core.InputSignal<"" | "right" | "left" | "both">;
    readonly padding: _angular_core.InputSignal<boolean>;
    readonly condensed: _angular_core.InputSignal<boolean>;
    readonly narrow: _angular_core.InputSignal<boolean>;
    protected get combinedClassNames(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RowDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<RowDirective, "[drv-row]", never, { "noGutter": { "alias": "noGutter"; "required": false; "isSignal": true; }; "padding": { "alias": "padding"; "required": false; "isSignal": true; }; "condensed": { "alias": "condensed"; "required": false; "isSignal": true; }; "narrow": { "alias": "narrow"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type IconLinkTarget = '_blank' | '_self' | '_parent' | '_top';
type IconLinkSize = 'default' | 'small';
type IconLinkVariant = 'inline' | 'block';
type IconLinkType = 'button' | 'anchor';
interface IconLinkData {
    id?: string;
    type?: string;
    size?: string;
    info?: string;
}
declare class IconlinkComponent {
    private router;
    readonly cssClass: _angular_core.InputSignal<string>;
    readonly href: _angular_core.InputSignal<string>;
    readonly route: _angular_core.InputSignal<string[] | Route[]>;
    readonly routeExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly subtitle: _angular_core.InputSignal<string>;
    readonly externalLinkText: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<IconLinkType>;
    readonly icon: _angular_core.InputSignal<IconType>;
    readonly variant: _angular_core.InputSignal<IconLinkVariant>;
    readonly size: _angular_core.InputSignal<IconLinkSize>;
    readonly target: _angular_core.InputSignal<IconLinkTarget>;
    readonly data: _angular_core.InputSignal<IconLinkData>;
    readonly downloadAble: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly itemClick: _angular_core.OutputEmitterRef<MouseEvent>;
    protected cssPrefix: string;
    protected get elementCssClass(): string;
    protected get getHref(): string;
    protected onClickHandler(event: PointerEvent | MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IconlinkComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IconlinkComponent, "drv-iconlink", never, { "cssClass": { "alias": "cssClass"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "route": { "alias": "route"; "required": false; "isSignal": true; }; "routeExtras": { "alias": "routeExtras"; "required": false; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; "externalLinkText": { "alias": "externalLinkText"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "size": { "alias": "size"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "downloadAble": { "alias": "downloadAble"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; }, never, ["*"], true, never>;
}

type IcontextTagname = 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'p';
type IcontextVariant = 'default' | 'decorative';
type IcontextHeadingClass = 'title-regular' | 'title-medium' | 'title-small';
declare class IcontextComponent {
    readonly iconType: _angular_core.InputSignal<IconType>;
    readonly tagName: _angular_core.InputSignal<IcontextTagname>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUI>;
    readonly variant: _angular_core.InputSignal<IcontextVariant>;
    private _headingClass;
    get headingClass(): string;
    set headingClass(classes: string);
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<IcontextComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<IcontextComponent, "drv-icontext", never, { "iconType": { "alias": "iconType"; "required": true; "isSignal": true; }; "tagName": { "alias": "tagName"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "headingClass": { "alias": "headingClass"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class ItemlistItemComponent implements AfterContentInit {
    private cdRef;
    readonly hostClass: _angular_core.InputSignal<string>;
    /** @internal */
    readonly itemTemplate: _angular_core.Signal<TemplateRef<unknown>>;
    /** @internal */
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ItemlistItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ItemlistItemComponent, "drv-itemlistitem", never, { "hostClass": { "alias": "hostClass"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ItemlistComponent {
    readonly isScrollable: _angular_core.InputSignal<boolean>;
    readonly hostClass: _angular_core.InputSignal<string>;
    readonly items: _angular_core.Signal<readonly ItemlistItemComponent[]>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ItemlistComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ItemlistComponent, "drv-itemlist", never, { "isScrollable": { "alias": "isScrollable"; "required": false; "isSignal": true; }; "hostClass": { "alias": "hostClass"; "required": false; "isSignal": true; }; }, {}, ["items"], ["*"], true, never>;
}

type LinklistColumns = 1 | 2 | 3 | 4;
type LinklistType = 'button' | 'anchor';
type LinklistPositions = 'left' | 'right';
interface LinklistData {
    icon: IconType;
    text: string;
    target?: IconLinkTarget;
    href?: string;
    route?: any[];
    routeExtras?: NavigationExtras;
    downloadAble?: boolean;
    disabled?: boolean;
    subtitle?: string;
    data?: IconLinkData;
}
declare class LinklistComponent extends ItemlistComponent {
    readonly columns: _angular_core.InputSignalWithTransform<number, LinklistColumns>;
    readonly data: _angular_core.InputSignal<LinklistData[]>;
    readonly type: _angular_core.InputSignal<LinklistType>;
    readonly iconPosition: _angular_core.InputSignal<LinklistPositions>;
    readonly itemClick: _angular_core.OutputEmitterRef<{
        item: LinklistData;
        event: MouseEvent;
    }>;
    readonly _links: _angular_core.Signal<readonly IconlinkComponent[]>;
    protected trackByFn: (index: number) => number;
    protected onClickHandler(item: LinklistData, event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LinklistComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LinklistComponent, "drv-linklist", never, { "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "iconPosition": { "alias": "iconPosition"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; }, never, never, true, never>;
}

interface VideoProps {
    poster: string;
    width: number;
    height: number;
    type: string;
    src: string;
}
interface EmbedProps {
    src: string;
    width: number;
    height: number;
    loading?: 'lazy' | 'eager';
    title: string;
}
interface ImageProps {
    src: string;
    width: number;
    height: number;
    loading?: 'lazy' | 'eager';
    alt: string;
    lightbox: boolean;
    srcset?: string[];
    sizes?: string;
}
declare class MediaComponent implements OnInit {
    private modalService;
    readonly variant: _angular_core.InputSignal<"default" | "caption-right" | "caption-left">;
    readonly aspectRatio: _angular_core.InputSignal<string>;
    readonly video: _angular_core.InputSignal<VideoProps>;
    readonly embed: _angular_core.InputSignal<EmbedProps>;
    readonly image: _angular_core.InputSignal<ImageProps>;
    readonly caption: _angular_core.InputSignal<string>;
    readonly duration: _angular_core.InputSignal<string>;
    readonly date: _angular_core.InputSignal<string>;
    readonly copyright: _angular_core.InputSignal<string>;
    readonly modalOpenButtonText: _angular_core.InputSignal<string>;
    readonly modalCloseButtonText: _angular_core.InputSignal<string>;
    readonly videoPlayButtonLabel: _angular_core.InputSignal<string>;
    readonly videoElement: _angular_core.Signal<ElementRef<any>>;
    protected modalId: string;
    protected isOpen: boolean;
    protected sanitizer: DomSanitizer;
    constructor();
    protected get cssClass(): string;
    protected get cssWrapperClass(): string;
    protected get aspectRatioStyle(): string | null;
    protected get responsiveImageProps(): string[];
    /** @internal */
    ngOnInit(): void;
    protected playVideo({ target }: {
        target: any;
    }): void;
    protected lightBoxClickHandler(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MediaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MediaComponent, "drv-media", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "aspectRatio": { "alias": "aspectRatio"; "required": false; "isSignal": true; }; "video": { "alias": "video"; "required": false; "isSignal": true; }; "embed": { "alias": "embed"; "required": false; "isSignal": true; }; "image": { "alias": "image"; "required": false; "isSignal": true; }; "caption": { "alias": "caption"; "required": false; "isSignal": true; }; "duration": { "alias": "duration"; "required": false; "isSignal": true; }; "date": { "alias": "date"; "required": false; "isSignal": true; }; "copyright": { "alias": "copyright"; "required": false; "isSignal": true; }; "modalOpenButtonText": { "alias": "modalOpenButtonText"; "required": false; "isSignal": true; }; "modalCloseButtonText": { "alias": "modalCloseButtonText"; "required": false; "isSignal": true; }; "videoPlayButtonLabel": { "alias": "videoPlayButtonLabel"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type ModalRole = 'alertdialog' | 'dialog';
interface Modal {
    id?: string;
    panelId?: string;
    open: boolean;
}
declare class ModalService {
    private modalData;
    private _modals;
    readonly modals: rxjs.Observable<Modal>;
    registerModal(id: string): void;
    unRegisterModal(id: string): void;
    updateModal(data: Modal): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ModalService>;
}

declare class ModalContentDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalContentDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ModalContentDirective, "drv-modal-content", never, {}, {}, never, never, true, never>;
}
declare class ModalActionsDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalActionsDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ModalActionsDirective, "drv-modal-actions", never, {}, {}, never, never, true, never>;
}
type ModalClosedBy = 'any' | 'closerequest' | 'none';
declare class ModalComponent implements OnDestroy, AfterViewInit, OnInit {
    private modalService;
    private supportsHTMLDialogClosedBy;
    private backdropClickListener?;
    private modalSubscription?;
    private handleDialogCloseBound;
    private handleDialogCancelBound;
    private handleCloseButtonClickBound;
    readonly modalTitle: _angular_core.InputSignal<string>;
    readonly closeButtonLabel: _angular_core.InputSignal<string>;
    readonly closeButtonIconOnlyType: _angular_core.InputSignal<IconOnlyType>;
    readonly hideCloseButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly isOpen: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly open: _angular_core.OutputEmitterRef<void>;
    /** @internal */
    readonly button: _angular_core.Signal<ButtonComponent>;
    /** @internal */
    readonly dialog: _angular_core.Signal<ElementRef<any>>;
    readonly role: _angular_core.InputSignal<ModalRole>;
    readonly modalId: _angular_core.InputSignal<string>;
    readonly closedBy: _angular_core.InputSignal<ModalClosedBy>;
    protected readonly modalTitleId: _angular_core.Signal<string>;
    protected readonly hideButton: _angular_core.Signal<boolean>;
    protected readonly closedByValue: _angular_core.Signal<ModalClosedBy>;
    constructor();
    /**
     * @internal
     * @returns {HTMLDialogElement | undefined} The native HTMLDialogElement or undefined if not available
     */
    private get dialogElement();
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    /**
     * Handle close button click
     * @internal
     */
    private handleCloseButtonClick;
    /**
     * Set the modal state (open or closed)
     * @param {boolean} open - Whether to open (true) or close (false) the modal
     */
    private setModalState;
    private setupDialogEventListeners;
    private handleBackdropClick;
    private handleDialogClose;
    private handleDialogCancel;
    private detectClosedBySupport;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ModalComponent, "drv-modal", never, { "modalTitle": { "alias": "modalTitle"; "required": false; "isSignal": true; }; "closeButtonLabel": { "alias": "closeButtonLabel"; "required": false; "isSignal": true; }; "closeButtonIconOnlyType": { "alias": "closeButtonIconOnlyType"; "required": false; "isSignal": true; }; "hideCloseButton": { "alias": "hideCloseButton"; "required": false; "isSignal": true; }; "isOpen": { "alias": "isOpen"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "modalId": { "alias": "modalId"; "required": true; "isSignal": true; }; "closedBy": { "alias": "closedBy"; "required": false; "isSignal": true; }; }, { "closed": "closed"; "open": "open"; }, never, ["drv-modal-content", "drv-modal-actions"], true, never>;
}

declare class ModalLegacyComponent implements OnDestroy, AfterViewInit, OnInit {
    private modalService;
    private elementRef;
    readonly modalTitle: _angular_core.InputSignal<string>;
    readonly closeButtonLabel: _angular_core.InputSignal<string>;
    readonly closeButtonIconOnlyType: _angular_core.InputSignal<IconOnlyType>;
    readonly hideCloseButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly open: _angular_core.OutputEmitterRef<void>;
    readonly button: _angular_core.Signal<ButtonComponent>;
    readonly role: _angular_core.InputSignal<ModalRole>;
    readonly modalId: _angular_core.InputSignal<string>;
    private undo;
    private dialog;
    private subscription;
    protected get modalTitleId(): string | undefined;
    protected get hideButton(): boolean;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    private subscribeToModals;
    private toggleDialog;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalLegacyComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ModalLegacyComponent, "drv-modal-legacy", never, { "modalTitle": { "alias": "modalTitle"; "required": false; "isSignal": true; }; "closeButtonLabel": { "alias": "closeButtonLabel"; "required": false; "isSignal": true; }; "closeButtonIconOnlyType": { "alias": "closeButtonIconOnlyType"; "required": false; "isSignal": true; }; "hideCloseButton": { "alias": "hideCloseButton"; "required": false; "isSignal": true; }; "role": { "alias": "role"; "required": false; "isSignal": true; }; "modalId": { "alias": "modalId"; "required": true; "isSignal": true; }; }, { "closed": "closed"; "open": "open"; }, never, ["drv-modal-content", "drv-modal-actions"], true, never>;
}

declare class ModalLegacyService {
    private modalData;
    private _modals;
    readonly modals: rxjs.Observable<Modal>;
    unRegisterModal(id: string): void;
    updateModal(data: Modal): Promise<void>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ModalLegacyService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ModalLegacyService>;
}

type NotificationVariant = 'alert' | 'warning' | 'success' | 'info';
interface Notification {
    id?: string;
    variant: NotificationVariant;
    title: string;
    text?: string;
    portalContent?: PortalContentType;
    isRemoveAble?: boolean;
    needsFeedback?: boolean;
    duration?: number;
    scrOnly?: boolean;
}
interface LocalNotification$1 extends Notification {
    notificationId?: string;
}
declare class NotificationService {
    private _notifications;
    private _removals;
    private _announcer;
    readonly notifications: rxjs.Observable<LocalNotification$1[]>;
    readonly removals: rxjs.Observable<string[]>;
    constructor();
    update(data: LocalNotification$1): void;
    remove(id: string): void;
    clear(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NotificationService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<NotificationService>;
}

type SymbolsType = 'status-archived' | 'status-deleted' | 'status-error' | 'status-in-progress' | 'status-info' | 'status-locked' | 'status-notified' | 'status-open' | 'status-processing' | 'status-protected' | 'status-stop' | 'status-success' | 'status-unknown' | 'status-warning';

interface LocalNotification extends Notification {
    notificationId?: string;
}
type NotificationType = 'toast' | 'inline' | 'banner';
type NotificationToastPosition = 'bottom' | 'right';
declare class NotificationComponent implements OnInit, OnChanges {
    private notificationService;
    private configService;
    readonly notificationId: _angular_core.InputSignal<string>;
    readonly type: _angular_core.ModelSignal<NotificationType>;
    readonly collapsible: _angular_core.InputSignal<boolean>;
    readonly inlineNotification: _angular_core.InputSignal<Notification>;
    readonly toastPosition: _angular_core.ModelSignal<NotificationToastPosition>;
    readonly closeButtonLabel: _angular_core.InputSignal<string>;
    readonly toggleButtonLabel: _angular_core.InputSignal<string>;
    readonly notificationClosed: _angular_core.OutputEmitterRef<string>;
    readonly buttons: _angular_core.Signal<readonly ButtonComponent[]>;
    protected hostClass: string;
    protected notifications: LocalNotification[];
    protected trackByFn: (index: number) => number;
    protected isOpen: boolean;
    private activeElement;
    constructor();
    protected get cssClass(): string;
    protected get ariaLive(): string;
    protected get isCollapsible(): boolean;
    protected keydownHandler(e: KeyboardEvent): void;
    /** @internal */
    ngOnInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    protected getIconType(variant: NotificationVariant): SymbolsType;
    protected isRemovable({ isRemoveAble }: {
        isRemoveAble?: boolean;
    }): boolean;
    protected getStyle({ needsFeedback, duration, variant }: {
        needsFeedback?: boolean;
        duration?: number;
        variant: any;
    }): string | null;
    protected removeNotification(e: AnimationEvent | MouseEvent, id: string): void;
    protected toggle(): void;
    private selector;
    private hasRemovableAlert;
    private removableAlertCount;
    private focusFirstButton;
    private addActiveElement;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NotificationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NotificationComponent, "drv-notification", never, { "notificationId": { "alias": "notificationId"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "collapsible": { "alias": "collapsible"; "required": false; "isSignal": true; }; "inlineNotification": { "alias": "inlineNotification"; "required": false; "isSignal": true; }; "toastPosition": { "alias": "toastPosition"; "required": false; "isSignal": true; }; "closeButtonLabel": { "alias": "closeButtonLabel"; "required": false; "isSignal": true; }; "toggleButtonLabel": { "alias": "toggleButtonLabel"; "required": false; "isSignal": true; }; }, { "type": "typeChange"; "toastPosition": "toastPositionChange"; "notificationClosed": "notificationClosed"; }, never, never, true, never>;
}

type PaginationVariant = 'default' | 'no-line' | 'compact';
declare class PaginationComponent implements OnChanges {
    readonly variant: _angular_core.InputSignal<PaginationVariant>;
    readonly pageText: _angular_core.InputSignal<string>;
    readonly prevPageText: _angular_core.InputSignal<string>;
    readonly nextPageText: _angular_core.InputSignal<string>;
    readonly firstPageText: _angular_core.InputSignal<string>;
    readonly lastPageText: _angular_core.InputSignal<string>;
    readonly pageFromLabel: _angular_core.InputSignal<string>;
    readonly pageMax: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly currentPage: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly firstAndLastButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly pageSelect: _angular_core.OutputEmitterRef<number>;
    readonly paginationLabel: _angular_core.InputSignal<string>;
    protected activePage: number;
    protected trackByFn: (index: number) => number;
    protected get pages(): number[];
    protected get disabledPrev(): boolean;
    protected get disabledNext(): boolean;
    protected get showMorePagesBackwards(): boolean;
    protected get showMorePagesForward(): boolean;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    protected selectPage(event: MouseEvent, page: number): void;
    protected prev(event: Event): void;
    protected next(event: Event): void;
    protected first(event: Event): void;
    protected last(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PaginationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PaginationComponent, "drv-pagination", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "pageText": { "alias": "pageText"; "required": false; "isSignal": true; }; "prevPageText": { "alias": "prevPageText"; "required": false; "isSignal": true; }; "nextPageText": { "alias": "nextPageText"; "required": false; "isSignal": true; }; "firstPageText": { "alias": "firstPageText"; "required": false; "isSignal": true; }; "lastPageText": { "alias": "lastPageText"; "required": false; "isSignal": true; }; "pageFromLabel": { "alias": "pageFromLabel"; "required": false; "isSignal": true; }; "pageMax": { "alias": "pageMax"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; "firstAndLastButton": { "alias": "firstAndLastButton"; "required": false; "isSignal": true; }; "paginationLabel": { "alias": "paginationLabel"; "required": true; "isSignal": true; }; }, { "pageSelect": "pageSelect"; }, never, never, true, never>;
}

declare class PasswordComponent extends FormitemComponent {
    readonly valueAccessor: ValueAccessorDirective<string>;
    private configService;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly minLength: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly maxLength: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly showPasswordButtonLabel: _angular_core.InputSignal<string>;
    readonly linkTitle: _angular_core.InputSignal<string>;
    readonly hasForgotPasswordLink: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly href: _angular_core.InputSignal<string>;
    readonly target: _angular_core.InputSignal<IconLinkTarget>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    readonly autocomplete: _angular_core.InputSignal<"current-password" | "new-password">;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    protected type: 'password' | 'text';
    protected iconType: IconType;
    protected showPassword: AriaPressedType;
    protected passwordButtonLabel: string;
    private innerValue?;
    constructor();
    protected get containerCssClasses(): string;
    protected get inputAriaAttributes(): AriaAttributes$2;
    protected get cssElementClass(): string;
    get value(): string;
    set value(value: string);
    protected onFocusout(event: FocusEvent): void;
    protected toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<PasswordComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<PasswordComponent, "drv-password", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "showPasswordButtonLabel": { "alias": "showPasswordButtonLabel"; "required": false; "isSignal": true; }; "linkTitle": { "alias": "linkTitle"; "required": false; "isSignal": true; }; "hasForgotPasswordLink": { "alias": "hasForgotPasswordLink"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface RadioChange {
    source: RadiobuttonComponent;
    value: string | number;
}
declare class RadiobuttonComponent implements OnChanges, OnInit, OnDestroy {
    private parent;
    private inputGroupService;
    private changeDetector;
    private configService;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.ModelSignal<string>;
    readonly value: _angular_core.InputSignal<string | number>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly backgroundUI: _angular_core.ModelSignal<BackgroundUI>;
    readonly ariaAttributes: _angular_core.ModelSignal<AriaAttributes$2>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    readonly valueChange: _angular_core.OutputEmitterRef<RadioChange>;
    /** @internal */
    readonly enabled: EventEmitter<RadiobuttonComponent>;
    protected externalId: string;
    protected checked: boolean;
    private destroyed$;
    constructor();
    get containerCssClasses(): string;
    /** @internal */
    ngOnInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    protected onInputInteraction(event: Event): void;
    protected onInputClick(event: Event): void;
    private setAriaAttributes;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RadiobuttonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RadiobuttonComponent, "drv-radiobutton", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; }, { "name": "nameChange"; "disabled": "disabledChange"; "required": "requiredChange"; "backgroundUI": "backgroundUIChange"; "ariaAttributes": "ariaAttributesChange"; "valueChange": "valueChange"; "enabled": "enabled"; }, never, ["*"], true, never>;
}

type SearchbarVariant = 'default' | 'mini' | 'icon-only';
declare class SearchbarComponent extends FormitemComponent implements AfterContentInit {
    readonly valueAccessor: ValueAccessorDirective<string>;
    private configService;
    readonly label: _angular_core.InputSignal<string>;
    readonly buttonText: _angular_core.InputSignal<string>;
    readonly buttonTextClear: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly buttonDisabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly variant: _angular_core.InputSignal<SearchbarVariant>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maskOptions: _angular_core.InputSignal<MaskitoOptions>;
    readonly keyboardShortcut: _angular_core.InputSignal<string>;
    readonly input: _angular_core.Signal<ElementRef<HTMLInputElement>>;
    readonly searched: _angular_core.OutputEmitterRef<string>;
    readonly combobox: _angular_core.Signal<any>;
    protected externalId: string;
    private innerValue?;
    constructor();
    protected get containerCssClasses(): string;
    protected get cssWrapperClass(): string;
    protected get cssBgClass(): string;
    protected get inputAriaAttributes(): AriaAttributes$2;
    protected get iconOnly(): IconOnlyType;
    get value(): string;
    set value(value: string);
    protected onFocusout(event: FocusEvent): void;
    /** @internal */
    ngAfterContentInit(): void;
    protected clickHandler(): void;
    protected clickClearHandler(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SearchbarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SearchbarComponent, "drv-searchbar", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "buttonText": { "alias": "buttonText"; "required": true; "isSignal": true; }; "buttonTextClear": { "alias": "buttonTextClear"; "required": true; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "buttonDisabled": { "alias": "buttonDisabled"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "maskOptions": { "alias": "maskOptions"; "required": false; "isSignal": true; }; "keyboardShortcut": { "alias": "keyboardShortcut"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; "searched": "searched"; }, ["combobox"], ["drv-combobox"], true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

declare class TableExpandRowComponent implements AfterContentInit {
    readonly cdRef: ChangeDetectorRef;
    readonly buttonLabel: _angular_core.InputSignal<string>;
    readonly selected: _angular_core.InputSignal<boolean>;
    readonly expandChange: _angular_core.OutputEmitterRef<boolean>;
    readonly dblclick: _angular_core.OutputEmitterRef<Event>;
    /** @internal */
    readonly rowTemplate: _angular_core.Signal<TemplateRef<unknown>>;
    private _expanded;
    get expanded(): boolean;
    set expanded(value: boolean);
    /** @internal */
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableExpandRowComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableExpandRowComponent, "drv-table-expandrow", never, { "buttonLabel": { "alias": "buttonLabel"; "required": false; "isSignal": true; }; "selected": { "alias": "selected"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; }; }, { "expandChange": "expandChange"; "dblclick": "dblclick"; }, never, ["*"], true, never>;
}

type TableHeaderItemCollapseType = 'sm' | 'md' | 'lg' | 'xlg' | 'max';
type TableHeaderItemOrderType = 'asc' | 'desc';
type TableHeaderItemUnitType = 'em' | 'rem' | 'px' | '%';
type TableHeaderItemAlignmentType = 'start' | 'end';
interface TableHeaderItem {
    id?: string;
    label: string;
    labelHidden?: boolean;
    noSort?: boolean;
    sorted?: boolean;
    order?: TableHeaderItemOrderType;
    width?: {
        unit: TableHeaderItemUnitType;
        value: number;
    };
    collapses?: TableHeaderItemCollapseType;
    mainInfo?: boolean;
    sticky?: boolean;
    alignment?: TableHeaderItemAlignmentType;
    toggletip?: string;
    toggletipTemplate?: TemplateRef<unknown>;
}
interface SortEvent {
    index: number;
    order: TableHeaderItemOrderType;
}
declare class TableHeadComponent implements AfterViewInit, OnChanges, AfterContentInit {
    private elementRef;
    readonly data: _angular_core.ModelSignal<TableHeaderItem[]>;
    readonly selectable: _angular_core.InputSignal<boolean>;
    readonly sortable: _angular_core.InputSignal<boolean>;
    readonly expandable: _angular_core.InputSignal<boolean>;
    readonly allCheckboxLabel: _angular_core.InputSignal<string>;
    readonly expandAllLabel: _angular_core.InputSignal<string>;
    readonly expandableMobile: _angular_core.InputSignal<boolean>;
    readonly checked: _angular_core.InputSignal<boolean>;
    readonly indeterminate: _angular_core.InputSignal<boolean>;
    readonly expanded: _angular_core.ModelSignal<boolean>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly sorted: _angular_core.OutputEmitterRef<SortEvent>;
    readonly allSelected: _angular_core.OutputEmitterRef<boolean>;
    readonly expandChange: _angular_core.OutputEmitterRef<boolean>;
    readonly all: _angular_core.Signal<ElementRef<any>>;
    protected allId: string;
    protected getCellClass: (item: TableHeaderItem) => string | null;
    protected lastSortedIndex: number | null;
    ngAfterContentInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    protected getSort(item: TableHeaderItem): string | null;
    protected getSortIcon(head: TableHeaderItem): IconType;
    protected getWidth(item: TableHeaderItem): string | null;
    protected sortData(index: number): void;
    protected allCheckboxChange(): void;
    protected toggleAllExpandableRows(): void;
    protected trackByFn(index: number): number;
    private setCheckboxState;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableHeadComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableHeadComponent, "drv-thead", never, { "data": { "alias": "data"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "sortable": { "alias": "sortable"; "required": false; "isSignal": true; }; "expandable": { "alias": "expandable"; "required": false; "isSignal": true; }; "allCheckboxLabel": { "alias": "allCheckboxLabel"; "required": false; "isSignal": true; }; "expandAllLabel": { "alias": "expandAllLabel"; "required": false; "isSignal": true; }; "expandableMobile": { "alias": "expandableMobile"; "required": false; "isSignal": true; }; "checked": { "alias": "checked"; "required": false; "isSignal": true; }; "indeterminate": { "alias": "indeterminate"; "required": false; "isSignal": true; }; "expanded": { "alias": "expanded"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; }, { "data": "dataChange"; "expanded": "expandedChange"; "sorted": "sorted"; "allSelected": "allSelected"; "expandChange": "expandChange"; }, never, never, true, never>;
}

type TableDataBody = (string | number)[];
interface TableData {
    header: TableHeaderItem[];
    body?: TableDataBody[];
    selectedRows?: number[];
}
type OnSelectChange = {
    index: number;
    row?: TableDataBody | TableExpandRowComponent;
}[];
type SortFunction = (body: TableDataBody[], index: number, order: string) => TableDataBody[];
declare class TableComponent implements OnInit, AfterViewInit, AfterContentInit, OnDestroy, OnChanges {
    private elementRef;
    private cdRef;
    readonly hideCaption: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly sortable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly selectable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly expandableMobile: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly stickyHead: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fixedHeight: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly mainInfoAsHeaderCell: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly caption: _angular_core.InputSignal<string>;
    readonly variant: _angular_core.InputSignal<"default" | "condensed">;
    readonly layout: _angular_core.InputSignal<"fixed" | "default">;
    readonly layoutMobile: _angular_core.InputSignal<"default" | "stacked" | "stacked-labelled" | "stacked-columns" | "custom-grid">;
    readonly cellAlignmentVertical: _angular_core.InputSignal<"top" | "bottom" | "middle">;
    readonly data: _angular_core.ModelSignal<TableData>;
    readonly singleCheckboxLabel: _angular_core.InputSignal<string>;
    readonly allCheckboxLabel: _angular_core.InputSignal<string>;
    readonly expandableBtnLabel: _angular_core.InputSignal<string>;
    readonly sorted: _angular_core.OutputEmitterRef<SortEvent>;
    readonly selected: _angular_core.OutputEmitterRef<OnSelectChange>;
    readonly allSelected: _angular_core.OutputEmitterRef<boolean>;
    readonly boxes: _angular_core.Signal<readonly ElementRef<any>[]>;
    readonly all: _angular_core.Signal<ElementRef<any>>;
    readonly expandRows: _angular_core.Signal<readonly any[]>;
    readonly expandableRows: _angular_core.Signal<readonly any[]>;
    protected headerId: string;
    protected allId: string;
    protected boxesId: string;
    protected expandedRows: boolean[];
    protected allCheckBoxChecked: boolean;
    protected allCheckBoxIndeterminate: boolean;
    protected getCellClass: (item: TableHeaderItem) => string | null;
    protected trackByFn: (index: number) => number;
    private selectedRows;
    private rowLength;
    private scrollable;
    private observer;
    private destroyed$;
    private initialBody;
    protected get headerClassName(): string;
    protected get selectedRowsfromData(): number[];
    readonly sort: _angular_core.InputSignal<SortFunction>;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterContentInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngOnDestroy(): void;
    protected sortData({ index, order }: {
        index: any;
        order: any;
    }): void;
    protected allCheckboxChange(checked: any): void;
    protected checkboxChange(idx: number): void;
    protected getMainInfoLabel(index: number): string;
    protected isMainInfoCell(index: number): boolean;
    protected expandClick(row: TableExpandRowComponent | TableDataBody): void;
    protected expandRowClick(index: number): void;
    protected getInitialBodyIndex(item: TableDataBody): number;
    private setAllCheckboxAndEmit;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableComponent, "drv-table", never, { "hideCaption": { "alias": "hideCaption"; "required": false; "isSignal": true; }; "sortable": { "alias": "sortable"; "required": false; "isSignal": true; }; "selectable": { "alias": "selectable"; "required": false; "isSignal": true; }; "expandableMobile": { "alias": "expandableMobile"; "required": false; "isSignal": true; }; "stickyHead": { "alias": "stickyHead"; "required": false; "isSignal": true; }; "fixedHeight": { "alias": "fixedHeight"; "required": false; "isSignal": true; }; "mainInfoAsHeaderCell": { "alias": "mainInfoAsHeaderCell"; "required": false; "isSignal": true; }; "caption": { "alias": "caption"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "layoutMobile": { "alias": "layoutMobile"; "required": false; "isSignal": true; }; "cellAlignmentVertical": { "alias": "cellAlignmentVertical"; "required": false; "isSignal": true; }; "data": { "alias": "data"; "required": false; "isSignal": true; }; "singleCheckboxLabel": { "alias": "singleCheckboxLabel"; "required": false; "isSignal": true; }; "allCheckboxLabel": { "alias": "allCheckboxLabel"; "required": false; "isSignal": true; }; "expandableBtnLabel": { "alias": "expandableBtnLabel"; "required": false; "isSignal": true; }; "sort": { "alias": "sort"; "required": false; "isSignal": true; }; }, { "data": "dataChange"; "sorted": "sorted"; "selected": "selected"; "allSelected": "allSelected"; }, ["expandRows", "expandableRows"], ["tbody", "thead", "drv-thead"], true, never>;
}

declare class TableAnimatedComponent extends TableComponent implements OnInit, AfterViewInit {
    private elRef;
    /** @internal */
    animationsDisabled: boolean;
    constructor();
    /** @internal */
    ngAfterViewInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableAnimatedComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableAnimatedComponent, "drv-table-animated", never, {}, {}, never, ["*"], true, never>;
}

declare class TableExpandedRowComponent implements AfterContentInit {
    private cdRef;
    readonly colspan: _angular_core.InputSignalWithTransform<number, unknown>;
    /** @internal */
    readonly rowTemplate: _angular_core.Signal<TemplateRef<unknown>>;
    /** @internal */
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TableExpandedRowComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TableExpandedRowComponent, "drv-table-expandedrow", never, { "colspan": { "alias": "colspan"; "required": true; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class TextareaComponent extends FormitemComponent {
    readonly valueAccessor: ValueAccessorDirective<string>;
    private configService;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly rows: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly cols: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly hasCounter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly minLength: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly maxLength: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly counterLabel: _angular_core.InputSignal<string>;
    readonly counterFromLabel: _angular_core.InputSignal<string>;
    readonly counterLimitReachedMessage: _angular_core.InputSignal<string>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    readonly autogrow: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    protected get containerCssClasses(): string;
    private innerValue?;
    constructor();
    protected get charCount(): number;
    protected get readOutCounter(): boolean;
    protected get hasCounterLimitReached(): boolean;
    protected get inputAriaAttributes(): AriaAttributes$2;
    protected get cssInputClass(): string;
    get value(): string;
    set value(value: string);
    protected onFocusout(event: FocusEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextareaComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextareaComponent, "drv-textarea", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "rows": { "alias": "rows"; "required": false; "isSignal": true; }; "cols": { "alias": "cols"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "hasCounter": { "alias": "hasCounter"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "counterLabel": { "alias": "counterLabel"; "required": false; "isSignal": true; }; "counterFromLabel": { "alias": "counterFromLabel"; "required": false; "isSignal": true; }; "counterLimitReachedMessage": { "alias": "counterLimitReachedMessage"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "autogrow": { "alias": "autogrow"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

type TextInputType = 'text' | 'search' | 'url' | 'tel' | 'email' | 'number' | 'password' | 'date' | 'month' | 'week' | 'time' | 'datetime-local' | 'hidden';
type TextInputMode = 'none' | 'text' | 'tel' | 'url' | 'email' | 'numeric' | 'decimal' | 'search';
type TextInputAlign = 'start' | 'end';
declare class TextinputComponent extends FormitemComponent {
    private document;
    readonly valueAccessor: ValueAccessorDirective<string>;
    private configService;
    readonly id: _angular_core.InputSignal<string>;
    readonly type: _angular_core.InputSignal<TextInputType>;
    readonly name: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly hasCounter: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly minLength: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly maxLength: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly minDate: _angular_core.InputSignal<string | Date>;
    readonly maxDate: _angular_core.InputSignal<string | Date>;
    readonly stepDate: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly autocomplete: _angular_core.InputSignal<string>;
    readonly counterLabel: _angular_core.InputSignal<string>;
    readonly counterFromLabel: _angular_core.InputSignal<string>;
    readonly counterLimitReachedMessage: _angular_core.InputSignal<string>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly maskOptions: _angular_core.InputSignal<MaskitoOptions>;
    readonly inputMode: _angular_core.InputSignal<TextInputMode>;
    readonly textAlign: _angular_core.InputSignal<TextInputAlign>;
    readonly input: _angular_core.Signal<ElementRef<HTMLInputElement>>;
    readonly inputFieldMaxWidth: _angular_core.InputSignal<string>;
    protected externalId: string;
    private innerValue;
    constructor();
    protected get containerCssClasses(): string;
    protected get charCount(): number;
    protected get readOutCounter(): boolean;
    protected get hasCounterLimitReached(): boolean;
    protected get inputAriaAttributes(): AriaAttributes$2;
    protected get cssInputClass(): string;
    get value(): string;
    set value(value: string);
    protected onFocusout(event: FocusEvent): void;
    protected stringFromDate(input: string | Date): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TextinputComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TextinputComponent, "drv-textinput", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "hasCounter": { "alias": "hasCounter"; "required": false; "isSignal": true; }; "minLength": { "alias": "minLength"; "required": false; "isSignal": true; }; "maxLength": { "alias": "maxLength"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; "stepDate": { "alias": "stepDate"; "required": false; "isSignal": true; }; "autocomplete": { "alias": "autocomplete"; "required": false; "isSignal": true; }; "counterLabel": { "alias": "counterLabel"; "required": false; "isSignal": true; }; "counterFromLabel": { "alias": "counterFromLabel"; "required": false; "isSignal": true; }; "counterLimitReachedMessage": { "alias": "counterLimitReachedMessage"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "maskOptions": { "alias": "maskOptions"; "required": false; "isSignal": true; }; "inputMode": { "alias": "inputMode"; "required": false; "isSignal": true; }; "textAlign": { "alias": "textAlign"; "required": false; "isSignal": true; }; "inputFieldMaxWidth": { "alias": "inputFieldMaxWidth"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

declare class ToggletipComponent implements AfterViewInit {
    private elementRef;
    readonly btnTriggerLabel: _angular_core.InputSignal<string>;
    readonly btnCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipContent: _angular_core.Signal<ElementRef<HTMLElement>>;
    readonly toggletip: _angular_core.Signal<ElementRef<HTMLElement>>;
    protected visible: boolean;
    protected handleWindowClick(target: HTMLElement): void;
    /** @internal */
    ngAfterViewInit(): void;
    protected toggle(): void;
    private checkContentBox;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggletipComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToggletipComponent, "drv-toggletip", never, { "btnTriggerLabel": { "alias": "btnTriggerLabel"; "required": false; "isSignal": true; }; "btnCloseLabel": { "alias": "btnCloseLabel"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type OverflowmenuPlacing = 'end' | 'start';
type OverflowmenuBtnVariant = 'secondary' | 'tertiary';
declare class OverflowmenuComponent implements AfterContentInit, AfterViewInit, OnDestroy, OnInit {
    private menuService;
    private viewContainerRef;
    private document;
    readonly elementRef: ElementRef<any>;
    readonly placing: _angular_core.InputSignal<OverflowmenuPlacing>;
    readonly triggerButtonLabel: _angular_core.InputSignal<string>;
    readonly triggerButtonVariant: _angular_core.InputSignal<OverflowmenuBtnVariant>;
    readonly triggerButtonIcon: _angular_core.InputSignal<IconType>;
    readonly triggerButtonIconOnly: _angular_core.InputSignal<IconOnlyType>;
    readonly triggerButtonIconPosition: _angular_core.InputSignal<IconPositionType>;
    readonly buttons: _angular_core.Signal<readonly ButtonComponent[]>;
    readonly toggleButton: _angular_core.Signal<ElementRef<any>>;
    readonly menuContent: _angular_core.Signal<ElementRef<HTMLElement>>;
    readonly templatePortalContent: _angular_core.Signal<TemplateRef<unknown>>;
    protected isOpen: boolean;
    protected trackByFn: (index: number) => number;
    private templatePortal;
    private bodyPortalHost;
    private nextElement;
    constructor();
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterContentInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    toggle(open?: boolean): void;
    protected focusOutButton(): void;
    protected keyDown(event: KeyboardEvent): void;
    private calculatePosition;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverflowmenuComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OverflowmenuComponent, "drv-overflowmenu", never, { "placing": { "alias": "placing"; "required": false; "isSignal": true; }; "triggerButtonLabel": { "alias": "triggerButtonLabel"; "required": true; "isSignal": true; }; "triggerButtonVariant": { "alias": "triggerButtonVariant"; "required": false; "isSignal": true; }; "triggerButtonIcon": { "alias": "triggerButtonIcon"; "required": false; "isSignal": true; }; "triggerButtonIconOnly": { "alias": "triggerButtonIconOnly"; "required": false; "isSignal": true; }; "triggerButtonIconPosition": { "alias": "triggerButtonIconPosition"; "required": false; "isSignal": true; }; }, {}, ["buttons"], never, true, never>;
}

type StatusLayout = 'block' | 'inline';
type StatusVariant = 'default' | 'condensed';
type StatusBgColor = 'ui-01' | 'ui-02' | 'ui-04' | 'ui-05' | 'ui-09' | 'alert' | 'warning' | 'success';
declare class StatusComponent {
    readonly layout: _angular_core.InputSignal<StatusLayout>;
    readonly variant: _angular_core.InputSignal<StatusVariant>;
    readonly bgColor: _angular_core.InputSignal<StatusBgColor>;
    readonly icon: _angular_core.InputSignal<IconType>;
    readonly iconLabel: _angular_core.InputSignal<string>;
    protected get containerCssClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StatusComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StatusComponent, "drv-status", never, { "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "bgColor": { "alias": "bgColor"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "iconLabel": { "alias": "iconLabel"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class LoadingComponent implements OnDestroy, OnInit {
    private loadingService;
    readonly loadingId: _angular_core.InputSignal<string>;
    readonly accessibleText: _angular_core.InputSignal<string>;
    readonly loadingText: _angular_core.InputSignal<string>;
    protected isBusy: boolean;
    protected asProgress: boolean;
    private progress;
    private subscription;
    protected get ariaBusy(): boolean;
    protected get cssClasses(): string;
    protected get loadingProgress(): string;
    protected get progressPercentage(): string;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    protected hide(e: AnimationEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoadingComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<LoadingComponent, "drv-loading", never, { "loadingId": { "alias": "loadingId"; "required": true; "isSignal": true; }; "accessibleText": { "alias": "accessibleText"; "required": false; "isSignal": true; }; "loadingText": { "alias": "loadingText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface Loading {
    id: string;
    visible?: boolean;
    asProgress?: boolean;
    progress?: number;
}
declare class LoadingService {
    private _knobs;
    readonly knobs: rxjs.Observable<Loading>;
    updateKnobs(data: Loading): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<LoadingService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<LoadingService>;
}

declare class SpinnerComponent {
    readonly loadingText: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpinnerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpinnerComponent, "drv-spinner", never, { "loadingText": { "alias": "loadingText"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type UploadFieldVariantType = 'basic' | 'dropzone';
interface FileEventTarget$1 {
    target: {
        files: FileList;
    };
}
type FileEvent$1 = Event & FileEventTarget$1;
declare class UploadFieldComponent extends FormitemComponent implements AfterViewInit {
    readonly valueAccessor: ValueAccessorDirective<FileList>;
    private configService;
    readonly label: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly variant: _angular_core.InputSignal<UploadFieldVariantType>;
    readonly btnLabel: _angular_core.InputSignal<string>;
    readonly dropzoneText: _angular_core.InputSignal<string>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly accept: _angular_core.InputSignal<string>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    readonly wrapper: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    constructor();
    protected get containerCssClasses(): string;
    protected get wrapperClass(): string;
    protected get describedBy(): string | null;
    protected onFocusout(event: FocusEvent): void;
    /** @internal */
    ngAfterViewInit(): void;
    protected fileChange(event: Event | FileEvent$1): void;
    protected fileCancel(event: Event | FileEvent$1): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UploadFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UploadFieldComponent, "drv-uploadfield", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "btnLabel": { "alias": "btnLabel"; "required": false; "isSignal": true; }; "dropzoneText": { "alias": "dropzoneText"; "required": false; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; }, { "required": "requiredChange"; "disabled": "disabledChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface FileEventTarget {
    target: {
        files: FileList;
    };
}
type FileEvent = Event & FileEventTarget;
declare class UploadButtonComponent extends FormitemComponent {
    readonly valueAccessor: ValueAccessorDirective<FileList>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly label: _angular_core.InputSignal<string>;
    readonly multiple: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly accept: _angular_core.InputSignal<string>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    constructor();
    protected get containerCssClasses(): string;
    protected get wrapperClass(): string;
    protected get describedBy(): string | null;
    protected onFocusout(event: FocusEvent): void;
    protected fileChange(event: Event | FileEvent): void;
    protected fileCancel(event: Event | FileEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<UploadButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<UploadButtonComponent, "drv-upload", never, { "required": { "alias": "required"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "multiple": { "alias": "multiple"; "required": false; "isSignal": true; }; "accept": { "alias": "accept"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface FileListItem {
    id: string;
    name: string;
    href?: string;
    blob?: Blob;
    size: number;
    hasError?: boolean;
    deletable?: boolean;
    errorMessages?: FormItemMessage[];
    progress?: number | null;
    indeterminate?: boolean;
    downloadAble?: boolean;
    callbackFn?: () => void;
}
declare class FileListComponent implements OnChanges {
    readonly headline: _angular_core.InputSignal<string>;
    readonly fileList: _angular_core.InputSignal<FileListItem[]>;
    readonly deleteButtonLabel: _angular_core.InputSignal<string>;
    readonly cancelButtonLabel: _angular_core.InputSignal<string>;
    readonly progressBarLabel: _angular_core.InputSignal<string>;
    readonly progressBarFromLabel: _angular_core.InputSignal<string>;
    readonly externalLinkLabel: _angular_core.InputSignal<string>;
    readonly errorPrefix: _angular_core.InputSignal<string>;
    readonly deleted: _angular_core.OutputEmitterRef<FileListItem>;
    readonly cancelled: _angular_core.OutputEmitterRef<FileListItem>;
    protected templateList: FileListItem[];
    protected trackByFn: (index: number) => number;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    protected getListItemClass(item: FileListItem): string;
    protected fileListActionHandler(action: 'delete' | 'cancel', item: FileListItem): void;
    protected itemClickHandler(e: MouseEvent, item: FileListItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FileListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FileListComponent, "drv-filelist", never, { "headline": { "alias": "headline"; "required": false; "isSignal": true; }; "fileList": { "alias": "fileList"; "required": false; "isSignal": true; }; "deleteButtonLabel": { "alias": "deleteButtonLabel"; "required": true; "isSignal": true; }; "cancelButtonLabel": { "alias": "cancelButtonLabel"; "required": true; "isSignal": true; }; "progressBarLabel": { "alias": "progressBarLabel"; "required": true; "isSignal": true; }; "progressBarFromLabel": { "alias": "progressBarFromLabel"; "required": false; "isSignal": true; }; "externalLinkLabel": { "alias": "externalLinkLabel"; "required": false; "isSignal": true; }; "errorPrefix": { "alias": "errorPrefix"; "required": false; "isSignal": true; }; }, { "deleted": "deleted"; "cancelled": "cancelled"; }, never, never, true, never>;
}

type LinkTargetType = IconLinkTarget;
declare class TileComponent {
    private router;
    private configService;
    readonly title: _angular_core.InputSignal<string>;
    readonly pictogramType: _angular_core.InputSignal<PictogramsType>;
    readonly items: _angular_core.InputSignal<string[]>;
    readonly href: _angular_core.InputSignal<string>;
    readonly route: _angular_core.InputSignal<string[] | Route[]>;
    readonly isExternal: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly linkTarget: _angular_core.InputSignal<IconLinkTarget>;
    readonly routeExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly hideDescriptionTextOnSmall: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected iconSpritePath: string;
    protected trackByFn: (index: number) => number;
    constructor();
    protected get getHref(): string;
    protected onClickHandler(event: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TileComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TileComponent, "drv-tile", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "pictogramType": { "alias": "pictogramType"; "required": true; "isSignal": true; }; "items": { "alias": "items"; "required": true; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "route": { "alias": "route"; "required": false; "isSignal": true; }; "isExternal": { "alias": "isExternal"; "required": false; "isSignal": true; }; "linkTarget": { "alias": "linkTarget"; "required": false; "isSignal": true; }; "routeExtras": { "alias": "routeExtras"; "required": false; "isSignal": true; }; "hideDescriptionTextOnSmall": { "alias": "hideDescriptionTextOnSmall"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

declare class ProgressnavComponent {
    readonly progressNavTitle: _angular_core.InputSignal<string>;
    readonly showOnMobile: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressnavComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressnavComponent, "drv-progressnav", never, { "progressNavTitle": { "alias": "progressNavTitle"; "required": true; "isSignal": true; }; "showOnMobile": { "alias": "showOnMobile"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ProgressnavService {
    private currentPage;
    readonly currentPage$: rxjs.Observable<ElementRef<any>>;
    setCurrentPage(anchor: ElementRef): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressnavService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<ProgressnavService>;
}

declare class ProgressnavNodeComponent implements AfterViewInit, OnInit {
    private router;
    private progressnavService;
    private configService;
    readonly name: _angular_core.InputSignal<string>;
    readonly url: _angular_core.InputSignal<string>;
    readonly route: _angular_core.InputSignal<string[] | Route[]>;
    readonly routeExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly completed: _angular_core.ModelSignal<boolean>;
    readonly active: _angular_core.ModelSignal<boolean>;
    readonly current: _angular_core.ModelSignal<boolean>;
    readonly isExpanded: _angular_core.ModelSignal<boolean>;
    readonly error: _angular_core.ModelSignal<boolean>;
    readonly disabled: _angular_core.ModelSignal<string | boolean>;
    readonly expandChange: _angular_core.OutputEmitterRef<boolean>;
    readonly itemClick: _angular_core.OutputEmitterRef<MouseEvent>;
    readonly labelCompleted: _angular_core.InputSignal<string>;
    readonly labelNotCompleted: _angular_core.InputSignal<string>;
    readonly toggleButtonLabel: _angular_core.InputSignal<string>;
    readonly subnav: _angular_core.Signal<any>;
    readonly anchor: _angular_core.Signal<ElementRef<any>>;
    /** @internal */
    icon: SymbolsType;
    protected get getIconType(): SymbolsType;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    protected getHref(): string;
    protected nodeClickHandler(event: MouseEvent): void;
    protected iconClickHandler(e: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ProgressnavNodeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ProgressnavNodeComponent, "drv-progressnavnode", never, { "name": { "alias": "name"; "required": false; "isSignal": true; }; "url": { "alias": "url"; "required": false; "isSignal": true; }; "route": { "alias": "route"; "required": false; "isSignal": true; }; "routeExtras": { "alias": "routeExtras"; "required": false; "isSignal": true; }; "completed": { "alias": "completed"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "current": { "alias": "current"; "required": false; "isSignal": true; }; "isExpanded": { "alias": "isExpanded"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "labelCompleted": { "alias": "labelCompleted"; "required": false; "isSignal": true; }; "labelNotCompleted": { "alias": "labelNotCompleted"; "required": false; "isSignal": true; }; "toggleButtonLabel": { "alias": "toggleButtonLabel"; "required": false; "isSignal": true; }; }, { "completed": "completedChange"; "active": "activeChange"; "current": "currentChange"; "isExpanded": "isExpandedChange"; "error": "errorChange"; "disabled": "disabledChange"; "expandChange": "expandChange"; "itemClick": "itemClick"; }, ["subnav"], never, true, never>;
}

declare class SubProgressnavComponent implements AfterContentInit {
    private cdRef;
    readonly level: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly isExpanded: _angular_core.ModelSignal<boolean>;
    /** @internal */
    readonly subtreeTemplate: _angular_core.Signal<TemplateRef<unknown>>;
    /** @internal */
    readonly items: _angular_core.Signal<readonly any[]>;
    protected get styleProps(): string;
    /** @internal */
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SubProgressnavComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SubProgressnavComponent, "drv-subprogressnav", never, { "level": { "alias": "level"; "required": false; "isSignal": true; }; "isExpanded": { "alias": "isExpanded"; "required": false; "isSignal": true; }; }, { "isExpanded": "isExpandedChange"; }, ["items"], ["*"], true, never>;
}

declare class TabpanelComponent implements AfterContentInit {
    private cdRef;
    readonly title: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<IconType>;
    readonly active: _angular_core.ModelSignal<boolean>;
    /** @internal */
    readonly panelTemplate: _angular_core.Signal<TemplateRef<unknown>>;
    /** @internal */
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TabpanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TabpanelComponent, "drv-tabpanel", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; }, { "active": "activeChange"; }, never, ["*"], true, never>;
}

interface TabChange {
    to: number;
    from: number;
}
declare class TablistComponent implements AfterViewInit, AfterContentInit {
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUI>;
    readonly paddedContent: _angular_core.InputSignal<boolean>;
    readonly tabChange: _angular_core.OutputEmitterRef<TabChange>;
    protected panels: QueryList<TabpanelComponent>;
    protected sections: QueryList<ElementRef>;
    /** @internal */
    readonly tabs: _angular_core.Signal<readonly ElementRef<any>[]>;
    /** @internal */
    readonly items: _angular_core.Signal<readonly ElementRef<any>[]>;
    /** @internal */
    readonly list: _angular_core.Signal<ElementRef<any>>;
    protected id: string;
    protected trackByFn: (index: number) => number;
    private scrollLeft;
    private maxScrollLeft;
    private isOverflowing;
    private intersections;
    constructor();
    protected get prevButtonClass(): string;
    protected get nextButtonClass(): string;
    protected get maskOpacity(): string;
    /** @internal */
    ngAfterContentInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    protected setActive(index: number, focus?: boolean): void;
    protected handleClick(e: Event, panel: TabpanelComponent, index: number): void;
    protected handleNavButtonClick(direction: 'left' | 'right'): void;
    protected handleKeyDown(event: KeyboardEvent, index: number): void;
    protected handleScroll(event: Event): void;
    private setFirstPanelActive;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TablistComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TablistComponent, "drv-tablist", never, { "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "paddedContent": { "alias": "paddedContent"; "required": false; "isSignal": true; }; }, { "tabChange": "tabChange"; }, ["panels"], never, true, never>;
}

declare class SegmentedButtonComponent implements AfterContentInit, OnChanges {
    readonly activeIndex: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly buttonClick: _angular_core.OutputEmitterRef<number>;
    readonly _buttons: _angular_core.Signal<readonly any[]>;
    readonly pressedSuffixText: _angular_core.InputSignal<string>;
    readonly pressedAnnounceText: _angular_core.InputSignal<string>;
    private selectedIndex;
    private buttonArr;
    private buttonLabels;
    private _announcer;
    constructor();
    /** @internal */
    ngAfterContentInit(): void;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    protected clickHandler(button: ButtonComponent): () => void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SegmentedButtonComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SegmentedButtonComponent, "drv-segmentedbutton", never, { "activeIndex": { "alias": "activeIndex"; "required": false; "isSignal": true; }; "pressedSuffixText": { "alias": "pressedSuffixText"; "required": false; "isSignal": true; }; "pressedAnnounceText": { "alias": "pressedAnnounceText"; "required": false; "isSignal": true; }; }, { "buttonClick": "buttonClick"; }, ["_buttons"], ["*"], true, never>;
}

interface FooterLinkItem {
    href?: string;
    text: string;
    htmltarget?: string;
    htmltitle?: string;
    icon?: IconType;
    route?: any[];
    routeExtras?: NavigationExtras;
    callbackFn?: () => void;
}
declare class FooterComponent {
    private router;
    readonly items: _angular_core.InputSignal<FooterLinkItem[]>;
    readonly copyright: _angular_core.InputSignal<string>;
    readonly version: _angular_core.InputSignal<string>;
    readonly footertext: _angular_core.InputSignal<string>;
    readonly columns: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly showVersion: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUILightDark>;
    protected trackByFn: (index: number) => number;
    protected getHref(item: FooterLinkItem): string;
    protected itemClickHandler(e: MouseEvent, item: FooterLinkItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FooterComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FooterComponent, "drv-footer", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "copyright": { "alias": "copyright"; "required": false; "isSignal": true; }; "version": { "alias": "version"; "required": false; "isSignal": true; }; "footertext": { "alias": "footertext"; "required": false; "isSignal": true; }; "columns": { "alias": "columns"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "showVersion": { "alias": "showVersion"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface FormError {
    id: string;
    text: string;
}
declare class FormerrorsComponent {
    readonly routerLink: _angular_core.InputSignal<string[]>;
    readonly errorHeadline: _angular_core.InputSignal<string>;
    readonly hintHeadline: _angular_core.InputSignal<string>;
    readonly hasErrors: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly hasHints: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected trackByFn: (index: number) => number;
    private _errors;
    private _hints;
    get errors(): FormError[];
    set errors(errorArray: FormError[]);
    get hints(): FormError[];
    set hints(errorArray: FormError[]);
    removeNullValues(array: FormError[]): FormError[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormerrorsComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FormerrorsComponent, "drv-formerrors", never, { "routerLink": { "alias": "routerLink"; "required": false; "isSignal": true; }; "errorHeadline": { "alias": "errorHeadline"; "required": true; "isSignal": true; }; "hintHeadline": { "alias": "hintHeadline"; "required": true; "isSignal": true; }; "hasErrors": { "alias": "hasErrors"; "required": false; "isSignal": true; }; "hasHints": { "alias": "hasHints"; "required": false; "isSignal": true; }; "errors": { "alias": "errors"; "required": false; }; "hints": { "alias": "hints"; "required": false; }; }, {}, never, never, true, never>;
}

interface MainNavLinkItem {
    text: string;
    href?: string;
    active?: boolean;
    route?: any[];
    routeExtras?: NavigationExtras;
    callbackFn?: () => void;
    htmltarget?: string;
    htmltitle?: string;
    keyboardShortcut?: string;
}
interface MetanavLinkItem extends MainNavLinkItem {
    icon?: IconType;
    iconOnly?: boolean;
}
interface LangLinkItem extends MainNavLinkItem {
    languageCode: string;
}
declare class HeaderComponent implements OnInit, OnDestroy {
    private router;
    private configService;
    private breakpointObserver;
    private cdRef;
    readonly isLoggedIn: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly loginPrefix: _angular_core.InputSignal<string>;
    readonly infotextSuffix: _angular_core.InputSignal<string>;
    readonly loginName: _angular_core.InputSignal<string>;
    readonly menuButtonLabel: _angular_core.InputSignal<string>;
    readonly logoutButtonLabel: _angular_core.InputSignal<string>;
    readonly loginButtonLabel: _angular_core.InputSignal<string>;
    readonly metaItems: _angular_core.InputSignal<MetanavLinkItem[]>;
    readonly mainItems: _angular_core.InputSignal<MainNavLinkItem[]>;
    readonly langItems: _angular_core.InputSignal<LangLinkItem[]>;
    readonly statusIcon: _angular_core.InputSignal<IconType>;
    readonly statusText: _angular_core.InputSignal<string>;
    readonly ariaLabelNav: _angular_core.InputSignal<string>;
    readonly isManagementMode: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly managementModeText: _angular_core.InputSignal<string>;
    readonly logoLink: _angular_core.InputSignal<string>;
    readonly logoLinkRoute: _angular_core.InputSignal<string[] | Route[]>;
    readonly logoLinkRouteExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly logoAltText: _angular_core.InputSignal<string>;
    readonly headerLogoPath: _angular_core.InputSignal<string>;
    readonly headerLogoSmallPath: _angular_core.InputSignal<string>;
    readonly headerLogoPathDark: _angular_core.InputSignal<string>;
    readonly headerLogoSmallPathDark: _angular_core.InputSignal<string>;
    readonly headerLogoTitle: _angular_core.InputSignal<string>;
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly withThemeToggle: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly languageText: _angular_core.InputSignal<string>;
    readonly flyoutCloseBtnText: _angular_core.InputSignal<string>;
    readonly displayText: _angular_core.InputSignal<string>;
    readonly darkModeText: _angular_core.InputSignal<string>;
    readonly darkThemeCSSClass: _angular_core.InputSignal<string>;
    readonly withMoreContrastToggle: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly moreContrastText: _angular_core.InputSignal<string>;
    readonly moreContrastThemeCSSClass: _angular_core.InputSignal<string>;
    readonly buttonClick: _angular_core.OutputEmitterRef<Event>;
    readonly itemClick: _angular_core.OutputEmitterRef<MainNavLinkItem | MetanavLinkItem | LangLinkItem>;
    /** @internal */
    readonly languageMenu: _angular_core.Signal<ElementRef<HTMLElement>>;
    /** @internal */
    readonly displayMenu: _angular_core.Signal<ElementRef<HTMLElement>>;
    protected readonly breakpoint$: Observable<BreakpointState>;
    protected trackByFn: (index: number) => number;
    protected logoWidth: number;
    protected logoHeight: number;
    protected isExpanded: boolean;
    protected iconSpritePath: string;
    protected largeScreenBreakpoint: boolean;
    protected langMenuOpen: boolean;
    protected displayMenuOpen: boolean;
    protected darkMode: boolean;
    protected moreContrast: boolean;
    protected readonly withDisplayMenu: _angular_core.Signal<boolean>;
    private breakpoint;
    private subscription;
    private getImageDimensions;
    private showKeyboardshortcutTooltip;
    constructor();
    protected get logoHref(): string;
    protected handleWindowClick(target: HTMLElement): void;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    protected keyboardShortcutTooltip(item: MainNavLinkItem): string;
    protected getHref(item: MetanavLinkItem | MainNavLinkItem): string;
    protected toggle(): void;
    protected toggleLangMenu(): void;
    protected toggleDisplayMenu(): void;
    protected onLogoClick(e: MouseEvent): void;
    protected itemClickHandler(e: MouseEvent, item: MetanavLinkItem | MainNavLinkItem | LangLinkItem): void;
    protected darkModeChange(value: boolean): void;
    protected moreContrastChange(value: boolean): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<HeaderComponent, "drv-header", never, { "isLoggedIn": { "alias": "isLoggedIn"; "required": false; "isSignal": true; }; "loginPrefix": { "alias": "loginPrefix"; "required": false; "isSignal": true; }; "infotextSuffix": { "alias": "infotextSuffix"; "required": false; "isSignal": true; }; "loginName": { "alias": "loginName"; "required": false; "isSignal": true; }; "menuButtonLabel": { "alias": "menuButtonLabel"; "required": false; "isSignal": true; }; "logoutButtonLabel": { "alias": "logoutButtonLabel"; "required": false; "isSignal": true; }; "loginButtonLabel": { "alias": "loginButtonLabel"; "required": false; "isSignal": true; }; "metaItems": { "alias": "metaItems"; "required": false; "isSignal": true; }; "mainItems": { "alias": "mainItems"; "required": false; "isSignal": true; }; "langItems": { "alias": "langItems"; "required": false; "isSignal": true; }; "statusIcon": { "alias": "statusIcon"; "required": false; "isSignal": true; }; "statusText": { "alias": "statusText"; "required": false; "isSignal": true; }; "ariaLabelNav": { "alias": "ariaLabelNav"; "required": false; "isSignal": true; }; "isManagementMode": { "alias": "isManagementMode"; "required": false; "isSignal": true; }; "managementModeText": { "alias": "managementModeText"; "required": false; "isSignal": true; }; "logoLink": { "alias": "logoLink"; "required": false; "isSignal": true; }; "logoLinkRoute": { "alias": "logoLinkRoute"; "required": false; "isSignal": true; }; "logoLinkRouteExtras": { "alias": "logoLinkRouteExtras"; "required": false; "isSignal": true; }; "logoAltText": { "alias": "logoAltText"; "required": false; "isSignal": true; }; "headerLogoPath": { "alias": "headerLogoPath"; "required": true; "isSignal": true; }; "headerLogoSmallPath": { "alias": "headerLogoSmallPath"; "required": true; "isSignal": true; }; "headerLogoPathDark": { "alias": "headerLogoPathDark"; "required": false; "isSignal": true; }; "headerLogoSmallPathDark": { "alias": "headerLogoSmallPathDark"; "required": false; "isSignal": true; }; "headerLogoTitle": { "alias": "headerLogoTitle"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "withThemeToggle": { "alias": "withThemeToggle"; "required": false; "isSignal": true; }; "languageText": { "alias": "languageText"; "required": false; "isSignal": true; }; "flyoutCloseBtnText": { "alias": "flyoutCloseBtnText"; "required": false; "isSignal": true; }; "displayText": { "alias": "displayText"; "required": false; "isSignal": true; }; "darkModeText": { "alias": "darkModeText"; "required": false; "isSignal": true; }; "darkThemeCSSClass": { "alias": "darkThemeCSSClass"; "required": false; "isSignal": true; }; "withMoreContrastToggle": { "alias": "withMoreContrastToggle"; "required": false; "isSignal": true; }; "moreContrastText": { "alias": "moreContrastText"; "required": false; "isSignal": true; }; "moreContrastThemeCSSClass": { "alias": "moreContrastThemeCSSClass"; "required": false; "isSignal": true; }; }, { "buttonClick": "buttonClick"; "itemClick": "itemClick"; }, never, never, true, never>;
}

interface NavigationItemAction {
    label: string;
    icon?: IconType;
    callbackFn?: () => void;
    route?: any[];
    routeExtras?: NavigationExtras;
}
interface NavigationItem {
    text: string;
    icon?: IconType;
    href?: string;
    target?: '_self' | '_blank' | '_parent' | '_top';
    route?: any[];
    routeExtras?: NavigationExtras;
    callbackFn?: () => void;
    badgeNumber?: number;
    active?: boolean;
    actions?: NavigationItemAction[];
}
declare class NavigationListComponent implements OnChanges {
    private router;
    readonly items: _angular_core.InputSignal<NavigationItem[]>;
    readonly actionsTriggerButtonLabel: _angular_core.InputSignal<string>;
    readonly showTooltips: _angular_core.ModelSignal<boolean>;
    readonly overFlowMenuClick: _angular_core.OutputEmitterRef<[number, number]>;
    itemClick: EventEmitter<NavigationItemAction | NavigationItem>;
    itemChange: EventEmitter<any>;
    protected trackByFn: (index: number) => number;
    protected nanoid: string;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    protected getHref(item: NavigationItem): string;
    protected overflowMenuClick(itemsIndex: number, actionIndex: number, btn: NavigationItemAction): void;
    protected itemClickHandler(e: MouseEvent, item: NavigationItem): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationListComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationListComponent, "drv-navigation-list", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "actionsTriggerButtonLabel": { "alias": "actionsTriggerButtonLabel"; "required": false; "isSignal": true; }; "showTooltips": { "alias": "showTooltips"; "required": false; "isSignal": true; }; }, { "showTooltips": "showTooltipsChange"; "overFlowMenuClick": "overFlowMenuClick"; "itemClick": "itemClick"; "itemChange": "itemChange"; }, never, never, true, never>;
}

interface ActiveNavigationItem {
    label?: string;
    text?: string;
    icon?: IconType;
    badgeNumber?: number;
}
declare class NavigationComponent implements AfterViewInit, AfterContentInit, OnDestroy {
    readonly navLabel: _angular_core.InputSignal<string>;
    readonly navButtonLabel: _angular_core.InputSignal<string>;
    readonly showToggleButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly toggleButtonText: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly button: _angular_core.Signal<ElementRef<any>>;
    private _navs;
    protected isOpen: boolean;
    protected activeItem: ActiveNavigationItem;
    private destroyed$;
    protected handleWindowResize(): void;
    /** @internal */
    ngAfterContentInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    protected toggle(): void;
    protected sideMenuCalc(): void;
    private updateNavs;
    private setNavActiveItem;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NavigationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NavigationComponent, "drv-navigation", never, { "navLabel": { "alias": "navLabel"; "required": true; "isSignal": true; }; "navButtonLabel": { "alias": "navButtonLabel"; "required": false; "isSignal": true; }; "showToggleButton": { "alias": "showToggleButton"; "required": false; "isSignal": true; }; "toggleButtonText": { "alias": "toggleButtonText"; "required": false; "isSignal": true; }; }, {}, ["_navs"], ["*"], true, never>;
}

interface InputGroupChild {
    id: string;
    value: string | number;
    checked?: boolean;
    disabled: boolean;
}
declare class InputGroupComponent implements AfterContentInit, OnChanges, OnDestroy, OnInit {
    readonly valueAccessor: ValueAccessorDirective<(string | number)[]>;
    private configService;
    private inputGroupService;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly innerValue: _angular_core.ModelSignal<(string | number)[]>;
    readonly grouplabel: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<unknown>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUI>;
    readonly layout: _angular_core.InputSignal<"inline" | "block" | "columns">;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly hasError: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly errorText: _angular_core.InputSignal<FormItemMessage[]>;
    readonly errorPrefix: _angular_core.InputSignal<string>;
    readonly hasInfo: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly infoText: _angular_core.InputSignal<FormItemMessage[]>;
    readonly infoPrefix: _angular_core.InputSignal<string>;
    readonly hasWarning: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly warningText: _angular_core.InputSignal<FormItemMessage[]>;
    readonly warningPrefix: _angular_core.InputSignal<string>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly collapseMessages: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly announceChanges: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly wrapper: _angular_core.Signal<ElementRef<any>>;
    readonly valueChange: _angular_core.OutputEmitterRef<(string | number)[]>;
    /** @internal */
    children: Map<RadiobuttonComponent | CheckboxComponent, InputGroupChild>;
    protected trackByFn: (index: number) => number;
    private checkingState;
    private labelClicked;
    private destroyed$;
    constructor();
    get cssClasses(): string[];
    get isRadioInputGroup(): boolean;
    get isCheckboxInputGroup(): boolean;
    get value(): (string | number)[];
    set value(value: (string | number)[]);
    ngOnInit(): void;
    /** @internal */
    ngAfterContentInit(): void;
    /** @internal */
    ngOnChanges(): void;
    /** @internal */
    ngOnDestroy(): void;
    protected onFocusout(event: FocusEvent): void;
    protected onFocusIn(e: FocusEvent): void;
    protected labelClick({ target }: {
        target: any;
    }): void;
    private setValue;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InputGroupComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InputGroupComponent, "drv-inputgroup", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "innerValue": { "alias": "value"; "required": false; "isSignal": true; }; "grouplabel": { "alias": "grouplabel"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "hasError": { "alias": "hasError"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; "errorPrefix": { "alias": "errorPrefix"; "required": false; "isSignal": true; }; "hasInfo": { "alias": "hasInfo"; "required": false; "isSignal": true; }; "infoText": { "alias": "infoText"; "required": false; "isSignal": true; }; "infoPrefix": { "alias": "infoPrefix"; "required": false; "isSignal": true; }; "hasWarning": { "alias": "hasWarning"; "required": false; "isSignal": true; }; "warningText": { "alias": "warningText"; "required": false; "isSignal": true; }; "warningPrefix": { "alias": "warningPrefix"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "collapseMessages": { "alias": "collapseMessages"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "announceChanges": { "alias": "announceChanges"; "required": false; "isSignal": true; }; }, { "innerValue": "valueChange"; "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; "valueChange": "valueChange"; }, never, ["*"], true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

declare class RichtextComponent {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RichtextComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RichtextComponent, "drv-richtext", never, {}, {}, never, ["*"], true, never>;
}

interface BreadcrumbItemInterface {
    title: string;
    href?: string;
    route?: any[];
    routeExtras?: NavigationExtras;
}
declare class BreadcrumbComponent {
    private router;
    readonly breadcrumbItems: _angular_core.InputSignal<BreadcrumbItemInterface[]>;
    readonly breadcrumbAriaLabel: _angular_core.InputSignal<string>;
    readonly breadcrumbBackLinkOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected trackByFn: (index: number) => number;
    protected getHref(item: BreadcrumbItemInterface): string;
    protected onClickHandler(item: BreadcrumbItemInterface, e: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BreadcrumbComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BreadcrumbComponent, "drv-breadcrumb", never, { "breadcrumbItems": { "alias": "breadcrumbItems"; "required": false; "isSignal": true; }; "breadcrumbAriaLabel": { "alias": "breadcrumbAriaLabel"; "required": false; "isSignal": true; }; "breadcrumbBackLinkOnly": { "alias": "breadcrumbBackLinkOnly"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

type H1StyleType = 'title-large' | 'title-regular';
declare class StageComponent {
    readonly headline: _angular_core.InputSignal<string>;
    readonly introText: _angular_core.InputSignal<string>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUILightColor>;
    readonly h1Style: _angular_core.InputSignal<H1StyleType>;
    readonly breadcrumbItems: _angular_core.InputSignal<BreadcrumbItemInterface[]>;
    readonly breadcrumbAriaLabel: _angular_core.InputSignal<string>;
    readonly breadcrumbBackLinkOnly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fullWidth: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly renderWithGridMarkup: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected get h1CssStyle(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StageComponent, "drv-stage", never, { "headline": { "alias": "headline"; "required": true; "isSignal": true; }; "introText": { "alias": "introText"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "h1Style": { "alias": "h1Style"; "required": false; "isSignal": true; }; "breadcrumbItems": { "alias": "breadcrumbItems"; "required": false; "isSignal": true; }; "breadcrumbAriaLabel": { "alias": "breadcrumbAriaLabel"; "required": false; "isSignal": true; }; "breadcrumbBackLinkOnly": { "alias": "breadcrumbBackLinkOnly"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "renderWithGridMarkup": { "alias": "renderWithGridMarkup"; "required": false; "isSignal": true; }; }, {}, never, ["drv-richtext"], true, never>;
}

declare class StatusScreenComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly iconLabel: _angular_core.InputSignal<string>;
    readonly iconType: _angular_core.InputSignal<IconType>;
    readonly buttonLabel: _angular_core.InputSignal<string>;
    readonly buttonHref: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StatusScreenComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StatusScreenComponent, "drv-statusscreen", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "iconLabel": { "alias": "iconLabel"; "required": true; "isSignal": true; }; "iconType": { "alias": "iconType"; "required": false; "isSignal": true; }; "buttonLabel": { "alias": "buttonLabel"; "required": false; "isSignal": true; }; "buttonHref": { "alias": "buttonHref"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type SummaryVariantType = 'smaller' | 'equal';
type SummaryMainInfoHighlight = 'label' | 'value';
type SummaryLayoutType = 'block' | 'columns' | 'grid';
declare class SummaryComponent {
    readonly title: _angular_core.InputSignal<string>;
    readonly items: _angular_core.InputSignal<Record<string, string>>;
    readonly variant: _angular_core.InputSignal<SummaryVariantType>;
    readonly layout: _angular_core.InputSignal<SummaryLayoutType>;
    readonly mainInfoHighlight: _angular_core.InputSignal<SummaryMainInfoHighlight>;
    protected trackByFn: (index: number) => number;
    get cssClasses(): string;
    protected unsorted(): number;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SummaryComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SummaryComponent, "drv-summary", never, { "title": { "alias": "title"; "required": false; "isSignal": true; }; "items": { "alias": "items"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "mainInfoHighlight": { "alias": "mainInfoHighlight"; "required": false; "isSignal": true; }; }, {}, never, ["drv-buttonbar", "drv-overflowmenu"], true, never>;
}

type ApplicationHeaderLayout = 'multiline' | 'singleline';
declare class ApplicationHeaderComponent implements OnInit, AfterViewInit {
    private configService;
    readonly triggerButtonLabel: _angular_core.InputSignal<string>;
    readonly appTitle: _angular_core.InputSignal<string>;
    readonly pageTitle: _angular_core.InputSignal<string>;
    readonly statusText: _angular_core.InputSignal<string>;
    readonly headerLogoPath: _angular_core.InputSignal<string>;
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    readonly showLogo: _angular_core.InputSignal<boolean>;
    readonly logoAltText: _angular_core.InputSignal<string>;
    readonly clientNumber: _angular_core.InputSignal<string>;
    readonly clientName: _angular_core.InputSignal<string>;
    readonly layout: _angular_core.ModelSignal<ApplicationHeaderLayout>;
    readonly buttons: _angular_core.Signal<readonly ButtonComponent[]>;
    protected isOpen: boolean;
    protected logoWidth: number;
    protected logoHeight: number;
    protected initialized: boolean;
    private getImageDimensions;
    constructor();
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    protected toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ApplicationHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ApplicationHeaderComponent, "drv-applicationheader", never, { "triggerButtonLabel": { "alias": "triggerButtonLabel"; "required": true; "isSignal": true; }; "appTitle": { "alias": "appTitle"; "required": false; "isSignal": true; }; "pageTitle": { "alias": "pageTitle"; "required": false; "isSignal": true; }; "statusText": { "alias": "statusText"; "required": false; "isSignal": true; }; "headerLogoPath": { "alias": "headerLogoPath"; "required": false; "isSignal": true; }; "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; "showLogo": { "alias": "showLogo"; "required": false; "isSignal": true; }; "logoAltText": { "alias": "logoAltText"; "required": false; "isSignal": true; }; "clientNumber": { "alias": "clientNumber"; "required": false; "isSignal": true; }; "clientName": { "alias": "clientName"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; }, { "layout": "layoutChange"; }, ["buttons"], ["drv-button"], true, never>;
}

type SliderComponentVariant = 'default' | 'small';
declare class SliderComponent extends FormitemComponent {
    readonly valueAccessor: ValueAccessorDirective<string>;
    private configService;
    readonly name: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly min: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly max: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    readonly variant: _angular_core.InputSignal<SliderComponentVariant>;
    readonly minLabel: _angular_core.InputSignal<string>;
    readonly maxLabel: _angular_core.InputSignal<string>;
    readonly step: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly hideTextInput: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly input: _angular_core.Signal<ElementRef<any>>;
    protected externalId: string;
    readonly numberInput: _angular_core.Signal<ElementRef<any>>;
    private innerValue?;
    constructor();
    protected get containerCssClasses(): string;
    protected get cssWrapperClass(): string;
    protected get cssInputClass(): string;
    protected get cssNumberInputClass(): string;
    protected get cssVars(): string;
    protected get inputAriaAttributes(): AriaAttributes$2;
    protected get getMaxValueLength(): number;
    get value(): string | number;
    set value(value: string);
    protected inputHandler({ target }: {
        target: any;
    }): void;
    protected rangeHandler({ target }: {
        target: any;
    }): void;
    protected onFocusout(event: FocusEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SliderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SliderComponent, "drv-slider", never, { "name": { "alias": "name"; "required": true; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "min": { "alias": "min"; "required": true; "isSignal": true; }; "max": { "alias": "max"; "required": true; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "minLabel": { "alias": "minLabel"; "required": false; "isSignal": true; }; "maxLabel": { "alias": "maxLabel"; "required": false; "isSignal": true; }; "step": { "alias": "step"; "required": false; "isSignal": true; }; "hideTextInput": { "alias": "hideTextInput"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface ToggleChange {
    source: ToggleComponent;
    value: boolean;
}
type ToggleLayout = 'block' | 'inline';
type ToggleLabelStyle = 'bold' | 'normal';
declare class ToggleComponent {
    readonly valueAccessor: ValueAccessorDirective<boolean>;
    readonly id: _angular_core.InputSignal<string>;
    readonly externalLabelId: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly value: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly labelHidden: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUI>;
    readonly layout: _angular_core.InputSignal<ToggleLayout>;
    readonly labelStyle: _angular_core.InputSignal<ToggleLabelStyle>;
    readonly toggleStateOff: _angular_core.InputSignal<string>;
    readonly toggleStateOn: _angular_core.InputSignal<string>;
    readonly input: _angular_core.Signal<ElementRef<HTMLInputElement>>;
    readonly toggled: _angular_core.OutputEmitterRef<ToggleChange>;
    protected externalId: string;
    protected hostClass: string;
    private innerValue?;
    constructor();
    protected get title(): string;
    protected get containerCssClasses(): string;
    protected get labelClasses(): string;
    get model(): boolean;
    set model(value: boolean);
    protected onFocusout(event: FocusEvent): void;
    protected nativeChange(e: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ToggleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ToggleComponent, "drv-toggle", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "externalLabelId": { "alias": "externalLabelId"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "value": { "alias": "value"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": true; "isSignal": true; }; "labelHidden": { "alias": "labelHidden"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "layout": { "alias": "layout"; "required": false; "isSignal": true; }; "labelStyle": { "alias": "labelStyle"; "required": false; "isSignal": true; }; "toggleStateOff": { "alias": "toggleStateOff"; "required": false; "isSignal": true; }; "toggleStateOn": { "alias": "toggleStateOn"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "toggled": "toggled"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

type ChartSize = 'small' | 'medium' | 'large';
declare class DonutComponent implements OnInit, OnDestroy, AfterViewInit {
    readonly accessibleText: _angular_core.InputSignal<string>;
    readonly percent: _angular_core.ModelSignal<number>;
    readonly label: _angular_core.InputSignal<string>;
    readonly animated: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly type: _angular_core.InputSignal<ChartSize>;
    readonly outline: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly svg: _angular_core.Signal<ElementRef<any>>;
    protected size: number;
    protected strokeWidth: number;
    protected radius: number;
    protected innerRadius: number;
    protected innerRadiusSmall: number;
    protected labelId: string;
    protected reducedMotion: boolean;
    protected calculatedPercent: number;
    protected observer: IntersectionObserver;
    private startTime;
    private duration;
    protected get viewBox(): string;
    protected get getPath(): string;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    private draw;
    private getPathFromAngle;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DonutComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<DonutComponent, "drv-donut", never, { "accessibleText": { "alias": "accessibleText"; "required": true; "isSignal": true; }; "percent": { "alias": "percent"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "animated": { "alias": "animated"; "required": false; "isSignal": true; }; "type": { "alias": "type"; "required": false; "isSignal": true; }; "outline": { "alias": "outline"; "required": false; "isSignal": true; }; }, { "percent": "percentChange"; }, never, never, true, never>;
}

/** CollapsibleOnlyType breakpointa – when is it a collapsible, when not */
type CollapsibleOnlyType = 'only-xlg' | 'only-lg' | 'only-md' | 'only-sm';
declare class CollapsibleComponent {
    readonly buttonText: _angular_core.InputSignal<string>;
    readonly collapsibleOnly: _angular_core.InputSignal<CollapsibleOnlyType>;
    readonly fullWidthStretch: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly activeStateTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    protected isOpen: boolean;
    protected get contentClasses(): string;
    protected toggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CollapsibleComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CollapsibleComponent, "drv-collapsible", never, { "buttonText": { "alias": "buttonText"; "required": false; "isSignal": true; }; "collapsibleOnly": { "alias": "collapsibleOnly"; "required": false; "isSignal": true; }; "fullWidthStretch": { "alias": "fullWidthStretch"; "required": false; "isSignal": true; }; "activeStateTemplate": { "alias": "activeStateTemplate"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface JumplinkData {
    text: string;
    href: string;
}
declare class JumplinksComponent {
    data: LinklistData[];
    columns: LinklistColumns;
    protected templateData: LinklistData[];
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<JumplinksComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<JumplinksComponent, "drv-jumplinks", never, { "data": { "alias": "data"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_data: JumplinkData[];
    static ngAcceptInputType_columns: unknown;
}

declare class ItemlistAnimatedComponent extends ItemlistComponent implements AfterViewInit {
    /** @internal */
    animationsDisabled: boolean;
    constructor();
    /** @internal */
    ngAfterViewInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ItemlistAnimatedComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ItemlistAnimatedComponent, "drv-itemlist-animated", never, {}, {}, never, ["drv-pictogram"], true, never>;
}

declare class TreeViewNodeComponent implements AfterViewInit {
    private router;
    private treeViewService;
    readonly text: _angular_core.InputSignal<string>;
    readonly icon: _angular_core.InputSignal<IconType>;
    readonly href: _angular_core.InputSignal<string>;
    readonly route: _angular_core.InputSignal<string[] | Route[]>;
    readonly routeExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly badgeNumber: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly active: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly currentPage: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly expandChange: _angular_core.OutputEmitterRef<boolean>;
    readonly itemClick: _angular_core.OutputEmitterRef<MouseEvent>;
    /** @internal */
    readonly anchor: _angular_core.Signal<ElementRef<any>>;
    readonly subtree: _angular_core.Signal<any>;
    readonly elRef: ElementRef<any>;
    protected isExpanded: boolean;
    private anchors;
    constructor();
    /** @internal */
    ngAfterViewInit(): void;
    protected getHref(): string;
    protected nodeClickHandler(event: MouseEvent): void;
    protected iconClickHandler(e: PointerEvent | MouseEvent): void;
    protected nodeKeydownHandler(e: KeyboardEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeViewNodeComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeViewNodeComponent, "drv-treeviewnode", never, { "text": { "alias": "text"; "required": false; "isSignal": true; }; "icon": { "alias": "icon"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "route": { "alias": "route"; "required": false; "isSignal": true; }; "routeExtras": { "alias": "routeExtras"; "required": false; "isSignal": true; }; "badgeNumber": { "alias": "badgeNumber"; "required": false; "isSignal": true; }; "active": { "alias": "active"; "required": false; "isSignal": true; }; "currentPage": { "alias": "currentPage"; "required": false; "isSignal": true; }; }, { "expandChange": "expandChange"; "itemClick": "itemClick"; }, ["subtree"], never, true, never>;
}

declare class TreeViewComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly condensed: _angular_core.InputSignalWithTransform<boolean, unknown>;
    private activeIndex;
    protected items: QueryList<TreeViewNodeComponent>;
    protected keyEventHandler(e: KeyboardEvent): void;
    protected focusHandler(e: FocusEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TreeViewComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TreeViewComponent, "drv-treeview", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "condensed": { "alias": "condensed"; "required": false; "isSignal": true; }; }, {}, ["items"], ["*"], true, never>;
}

declare class SubTreeViewComponent implements AfterContentInit {
    private cdRef;
    readonly level: _angular_core.InputSignalWithTransform<number, unknown>;
    readonly id: _angular_core.InputSignal<string>;
    /** @internal */
    readonly subtreeTemplate: _angular_core.Signal<TemplateRef<unknown>>;
    /** @internal */
    items: QueryList<TreeViewNodeComponent>;
    protected get styleProps(): string;
    /** @internal */
    ngAfterContentInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SubTreeViewComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SubTreeViewComponent, "drv-subtreeview", never, { "level": { "alias": "level"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": true; "isSignal": true; }; }, {}, ["items"], ["*"], true, never>;
}

type SidepanelVariant = 'default' | 'modal';
type SidepanelSize = 'xsmall' | 'small' | 'medium' | 'large';
declare class SidepanelContentDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidepanelContentDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SidepanelContentDirective, "drv-sidepanel-content", never, {}, {}, never, never, true, never>;
}
declare class SidepanelActionsDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidepanelActionsDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<SidepanelActionsDirective, "drv-sidepanel-actions", never, {}, {}, never, never, true, never>;
}
declare class SidepanelComponent implements OnDestroy, AfterViewInit, OnInit {
    private modalService;
    private elementRef;
    readonly panelTitle: _angular_core.InputSignal<string>;
    readonly closeButtonLabel: _angular_core.InputSignal<string>;
    readonly hideCloseButton: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly panelSize: _angular_core.InputSignal<SidepanelSize>;
    readonly variant: _angular_core.InputSignal<SidepanelVariant>;
    readonly closed: _angular_core.OutputEmitterRef<void>;
    readonly open: _angular_core.OutputEmitterRef<void>;
    readonly panelId: _angular_core.InputSignal<string>;
    readonly button: _angular_core.Signal<ButtonComponent>;
    private dialog;
    private subscription;
    protected get panelTitleId(): string | undefined;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngAfterViewInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    private subscribeToModals;
    private toggleDialog;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidepanelComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SidepanelComponent, "drv-sidepanel", never, { "panelTitle": { "alias": "panelTitle"; "required": false; "isSignal": true; }; "closeButtonLabel": { "alias": "closeButtonLabel"; "required": true; "isSignal": true; }; "hideCloseButton": { "alias": "hideCloseButton"; "required": false; "isSignal": true; }; "panelSize": { "alias": "panelSize"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "panelId": { "alias": "panelId"; "required": true; "isSignal": true; }; }, { "closed": "closed"; "open": "open"; }, never, ["drv-sidepanel-content", "drv-sidepanel-actions"], true, never>;
}

declare class SidepanelService extends ModalService {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SidepanelService, never>;
    static ɵprov: _angular_core.ɵɵInjectableDeclaration<SidepanelService>;
}

type CallbackFunction = () => void;
declare class InsuranceNumberComponent extends FormitemComponent implements ControlValueAccessor, Validator, OnInit, OnDestroy {
    private controlContainer;
    private configService;
    readonly id: _angular_core.InputSignal<string>;
    readonly name: _angular_core.InputSignal<string>;
    readonly label: _angular_core.InputSignal<string>;
    readonly placeholder: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly required: _angular_core.ModelSignal<boolean>;
    readonly readonly: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes$2>;
    /** ensures that users type VSNR according to predefined format */
    readonly strict: _angular_core.ModelSignal<boolean>;
    /** content of the toggletip */
    readonly toggletip: _angular_core.InputSignal<string>;
    readonly toggletipLabel: _angular_core.InputSignal<string>;
    readonly toggletipCloseLabel: _angular_core.InputSignal<string>;
    readonly toggletipTemplate: _angular_core.InputSignal<TemplateRef<unknown>>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly validationErrorMessage: _angular_core.InputSignal<string>;
    readonly requiredErrorMessage: _angular_core.InputSignal<string>;
    readonly checksumErrorMessage: _angular_core.InputSignal<string>;
    readonly areacodeErrorMessage: _angular_core.InputSignal<string>;
    readonly formControlName: _angular_core.InputSignal<string>;
    readonly input: _angular_core.Signal<{
        nativeElement: HTMLInputElement;
    }>;
    protected externalId: string;
    protected get containerCssClasses(): string;
    readonly maskitoOptions: MaskitoOptions;
    protected maxLength: number;
    private innerValue?;
    private control;
    private onTouchedCallback?;
    private onChangeCallback?;
    private destroyed$;
    constructor();
    protected get inputAriaAttributes(): AriaAttributes$2;
    protected get cssInputClass(): string;
    get value(): string;
    set value(value: string);
    protected onFocusout(target: HTMLElement): void;
    /**
     * @param {FormControl} control FormControl
     * @returns {Record<string, unknown> | null} Validation result
     * @internal
     */
    validate(control: FormControl): Record<string, unknown> | null;
    /** @internal */
    ngOnInit(): void;
    /** @internal */
    ngOnDestroy(): void;
    /** @internal */
    onBlur(): void;
    /**
     * @param {string} value Value to write
     * @internal
     */
    writeValue(value: string): void;
    /**
     * @param {CallbackFunction} fn Callback function
     * @internal
     */
    registerOnChange(fn: CallbackFunction): void;
    /**
     * @param {CallbackFunction} fn Callback function
     * @internal
     */
    registerOnTouched(fn: CallbackFunction): void;
    /**
     * @param {boolean} isDisabled Is disabled
     * @internal
     */
    setDisabledState(isDisabled: boolean): void;
    protected onInputChange(value: string): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InsuranceNumberComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<InsuranceNumberComponent, "drv-insurancenumber", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "readonly": { "alias": "readonly"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; "strict": { "alias": "strict"; "required": false; "isSignal": true; }; "toggletip": { "alias": "toggletip"; "required": false; "isSignal": true; }; "toggletipLabel": { "alias": "toggletipLabel"; "required": false; "isSignal": true; }; "toggletipCloseLabel": { "alias": "toggletipCloseLabel"; "required": false; "isSignal": true; }; "toggletipTemplate": { "alias": "toggletipTemplate"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "validationErrorMessage": { "alias": "validationErrorMessage"; "required": false; "isSignal": true; }; "requiredErrorMessage": { "alias": "requiredErrorMessage"; "required": false; "isSignal": true; }; "checksumErrorMessage": { "alias": "checksumErrorMessage"; "required": false; "isSignal": true; }; "areacodeErrorMessage": { "alias": "areacodeErrorMessage"; "required": false; "isSignal": true; }; "formControlName": { "alias": "formControlName"; "required": false; "isSignal": true; }; }, { "disabled": "disabledChange"; "required": "requiredChange"; "strict": "strictChange"; "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; }, never, never, true, never>;
}

declare class InsuranceNumberFormatPipe implements PipeTransform {
    transform(input: string): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<InsuranceNumberFormatPipe, never>;
    static ɵpipe: _angular_core.ɵɵPipeDeclaration<InsuranceNumberFormatPipe, "insurancenumber", true>;
}

declare const formatValid: (vsnr: string, withoutChecksum?: boolean) => boolean;
declare const formatVSNR: (vsnr: string) => string;

type EmptyStatePictogramPosition = 'top' | 'side';
declare class EmptyStateComponent {
    readonly pictogramPosition: _angular_core.InputSignal<EmptyStatePictogramPosition>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EmptyStateComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EmptyStateComponent, "drv-emptystate", never, { "pictogramPosition": { "alias": "pictogramPosition"; "required": false; "isSignal": true; }; }, {}, never, ["drv-pictogram", "*"], true, never>;
}

type OverflowselectPlacing = 'end' | 'start';
type OverflowselectBtnVariant = 'secondary' | 'tertiary';
interface OverflowselectOption {
    label?: string;
    value?: string;
    disabled?: boolean;
    selected?: boolean;
    icon?: IconType;
}
interface OverflowselectOptionTemplate extends OverflowselectOption {
    hasFocus?: boolean;
}
type OverflowselectAriaAttributes = AriaAttributes & {
    activedescendant?: string;
    label?: string;
};
declare class OverflowselectComponent implements OnChanges, AfterViewInit {
    private elementRef;
    private deviceService;
    readonly placing: _angular_core.InputSignal<OverflowmenuPlacing>;
    readonly triggerButtonLabel: _angular_core.InputSignal<string>;
    readonly triggerButtonVariant: _angular_core.InputSignal<OverflowmenuBtnVariant>;
    readonly triggerButtonIcon: _angular_core.InputSignal<IconType>;
    readonly triggerButtonIconOnly: _angular_core.InputSignal<IconOnlyType>;
    readonly triggerButtonIconPosition: _angular_core.InputSignal<IconPositionType>;
    readonly options: _angular_core.InputSignal<OverflowselectOption[]>;
    readonly ariaAttributes: _angular_core.InputSignal<AriaAttributes>;
    readonly selectionChange: _angular_core.OutputEmitterRef<OverflowselectOption>;
    readonly button: _angular_core.Signal<ButtonComponent>;
    readonly listbox: _angular_core.Signal<ElementRef<any>>;
    readonly listitems: _angular_core.Signal<readonly ElementRef<any>[]>;
    protected isOpen: boolean;
    protected templateOptions: OverflowselectOptionTemplate[];
    protected id: string;
    protected trackByFn: (index: number) => number;
    private typeAheadTerm;
    private tyepAheadTimeout;
    protected get hostRole(): string | null;
    protected get triggerButtonAriaAttributes(): OverflowselectAriaAttributes;
    protected get activeDescendant(): string | null;
    protected get buttonLabel(): string;
    protected get buttonIcon(): IconType;
    protected get isMobile(): boolean;
    /**
     * @param {SimpleChanges} changes SimpleChanges
     * @internal
     */
    ngOnChanges(changes: SimpleChanges): void;
    /** @internal */
    ngAfterViewInit(): void;
    protected toggle(isOpen?: boolean, focusInput?: boolean): void;
    protected buttonFocusout(event: FocusEvent): void;
    protected buttonClickHandler(): void;
    protected keydownButton(event: KeyboardEvent): void;
    protected select(index: number): void;
    protected setValueFromSelect(event: Event): void;
    private getNeighbourIndex;
    private selectFromTypeAhead;
    private calculatePosition;
    private focusOption;
    private selectOption;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverflowselectComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OverflowselectComponent, "drv-overflowselect", never, { "placing": { "alias": "placing"; "required": false; "isSignal": true; }; "triggerButtonLabel": { "alias": "triggerButtonLabel"; "required": true; "isSignal": true; }; "triggerButtonVariant": { "alias": "triggerButtonVariant"; "required": false; "isSignal": true; }; "triggerButtonIcon": { "alias": "triggerButtonIcon"; "required": false; "isSignal": true; }; "triggerButtonIconOnly": { "alias": "triggerButtonIconOnly"; "required": false; "isSignal": true; }; "triggerButtonIconPosition": { "alias": "triggerButtonIconPosition"; "required": false; "isSignal": true; }; "options": { "alias": "options"; "required": false; "isSignal": true; }; "ariaAttributes": { "alias": "ariaAttributes"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; }, never, never, true, never>;
}

type FieldsetLegendStyle = 'underlined' | 'none';
declare class FieldsetComponent implements OnInit {
    readonly disabled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly fieldsetTitle: _angular_core.InputSignal<string>;
    readonly legendStyle: _angular_core.InputSignal<FieldsetLegendStyle>;
    readonly fieldsetElement: _angular_core.Signal<ElementRef<any>>;
    readonly id: _angular_core.InputSignal<string>;
    private fieldsetService;
    protected get legendCssClasses(): string;
    ngOnInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FieldsetComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<FieldsetComponent, "drv-fieldset", never, { "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "fieldsetTitle": { "alias": "fieldsetTitle"; "required": false; "isSignal": true; }; "legendStyle": { "alias": "legendStyle"; "required": false; "isSignal": true; }; "id": { "alias": "id"; "required": false; "isSignal": true; }; }, {}, never, ["[asFieldsetTitle]", "*"], true, never>;
}

type SpacerContentPlacing = 'start' | 'center' | 'end' | 'space-between' | 'space-between-first' | 'space-between-last';
type SpacingVariant = 'default' | 'contents' | 'sections';
declare class SpacerComponent {
    readonly placing: _angular_core.InputSignal<SpacerContentPlacing>;
    readonly variant: _angular_core.InputSignal<SpacingVariant>;
    protected get containerCssClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SpacerComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SpacerComponent, "drv-spacer", never, { "placing": { "alias": "placing"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface FieldsetShortcut {
    forward: string;
    backward: string;
}
declare class RootComponent implements OnInit {
    readonly fieldsetShortCuts: _angular_core.InputSignal<FieldsetShortcut>;
    private configService;
    private useReducedMotion;
    private document;
    private renderer;
    private fieldsetService;
    private fieldsets;
    private activeFieldset;
    constructor();
    ngOnInit(): void;
    private handleKeyboardShortcuts;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<RootComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<RootComponent, "drv-root", never, { "fieldsetShortCuts": { "alias": "fieldsetShortCuts"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class StarRatingComponent implements OnChanges {
    readonly id: _angular_core.InputSignal<string>;
    readonly grouplabel: _angular_core.InputSignal<string>;
    readonly requiredSign: _angular_core.ModelSignal<string>;
    readonly requiredSignTitleAttr: _angular_core.InputSignal<string>;
    readonly optionalText: _angular_core.ModelSignal<string>;
    readonly hasError: _angular_core.ModelSignal<boolean>;
    readonly errorText: _angular_core.ModelSignal<FormItemMessage[]>;
    readonly errorPrefix: _angular_core.InputSignal<string>;
    readonly hasInfo: _angular_core.ModelSignal<boolean>;
    readonly infoText: _angular_core.ModelSignal<FormItemMessage[]>;
    readonly infoPrefix: _angular_core.InputSignal<string>;
    readonly hasWarning: _angular_core.ModelSignal<boolean>;
    readonly warningText: _angular_core.ModelSignal<FormItemMessage[]>;
    readonly warningPrefix: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.ModelSignal<boolean>;
    readonly collapseMessages: _angular_core.ModelSignal<boolean>;
    readonly backgroundUI: _angular_core.InputSignal<BackgroundUI>;
    readonly announceChanges: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly required: _angular_core.ModelSignal<unknown>;
    readonly visuallyHiddenLabel: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly starText: _angular_core.InputSignal<string>;
    /** @internal */ _radios: QueryList<ElementRef>;
    protected ratingOptions: number[];
    protected rating: number;
    protected trackByFn: (index: number) => number;
    protected ariaAttributes: AriaAttributes$2;
    private labelClicked;
    /** @internal */
    readonly valueAccessor: ValueAccessorDirective<number>;
    private configService;
    constructor();
    get cssClasses(): string[];
    get value(): number;
    set value(value: number);
    /** @internal */
    ngOnChanges(): void;
    protected setRating(value: number): void;
    protected onFocusout(event: FocusEvent): void;
    protected onFocusIn(e: FocusEvent): void;
    protected labelClick({ target }: {
        target: any;
    }): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StarRatingComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StarRatingComponent, "drv-starrating", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "grouplabel": { "alias": "grouplabel"; "required": false; "isSignal": true; }; "requiredSign": { "alias": "requiredSign"; "required": false; "isSignal": true; }; "requiredSignTitleAttr": { "alias": "requiredSignTitleAttr"; "required": false; "isSignal": true; }; "optionalText": { "alias": "optionalText"; "required": false; "isSignal": true; }; "hasError": { "alias": "hasError"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; "errorPrefix": { "alias": "errorPrefix"; "required": false; "isSignal": true; }; "hasInfo": { "alias": "hasInfo"; "required": false; "isSignal": true; }; "infoText": { "alias": "infoText"; "required": false; "isSignal": true; }; "infoPrefix": { "alias": "infoPrefix"; "required": false; "isSignal": true; }; "hasWarning": { "alias": "hasWarning"; "required": false; "isSignal": true; }; "warningText": { "alias": "warningText"; "required": false; "isSignal": true; }; "warningPrefix": { "alias": "warningPrefix"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "collapseMessages": { "alias": "collapseMessages"; "required": false; "isSignal": true; }; "backgroundUI": { "alias": "backgroundUI"; "required": false; "isSignal": true; }; "announceChanges": { "alias": "announceChanges"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "visuallyHiddenLabel": { "alias": "visuallyHiddenLabel"; "required": false; "isSignal": true; }; "starText": { "alias": "starText"; "required": false; "isSignal": true; }; }, { "requiredSign": "requiredSignChange"; "optionalText": "optionalTextChange"; "hasError": "hasErrorChange"; "errorText": "errorTextChange"; "hasInfo": "hasInfoChange"; "infoText": "infoTextChange"; "hasWarning": "hasWarningChange"; "warningText": "warningTextChange"; "disabled": "disabledChange"; "collapseMessages": "collapseMessagesChange"; "required": "requiredChange"; }, never, never, true, [{ directive: typeof ValueAccessorDirective; inputs: {}; outputs: {}; }]>;
}

interface NfcFeedbackResult {
    identifier: string;
    value?: number | string;
}
declare class NFComponent {
    readonly id: _angular_core.InputSignal<string>;
    readonly required: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly feedbackTitle: _angular_core.InputSignal<string>;
    readonly question: _angular_core.InputSignal<string>;
    readonly buttonText: _angular_core.InputSignal<string>;
    readonly successTitle: _angular_core.InputSignal<string>;
    readonly successText: _angular_core.InputSignal<string>;
    readonly errorText: _angular_core.InputSignal<string>;
    readonly hasFreeText: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly freeTextLabel: _angular_core.InputSignal<string>;
    readonly freeTextMaxLength: _angular_core.InputSignal<number>;
    readonly formSubmit: _angular_core.OutputEmitterRef<NfcFeedbackResult[]>;
    private nService;
    private fb;
    protected isSubmitted: boolean;
    protected invalidOnSubmit: boolean;
    private questionIdentifier;
    private freeTextIdentifier;
    form: UntypedFormGroup;
    protected get containerCssClasses(): string;
    onSubmit(event: Event): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<NFComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<NFComponent, "drv-nfk", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; "feedbackTitle": { "alias": "feedbackTitle"; "required": false; "isSignal": true; }; "question": { "alias": "question"; "required": false; "isSignal": true; }; "buttonText": { "alias": "buttonText"; "required": false; "isSignal": true; }; "successTitle": { "alias": "successTitle"; "required": false; "isSignal": true; }; "successText": { "alias": "successText"; "required": false; "isSignal": true; }; "errorText": { "alias": "errorText"; "required": false; "isSignal": true; }; "hasFreeText": { "alias": "hasFreeText"; "required": false; "isSignal": true; }; "freeTextLabel": { "alias": "freeTextLabel"; "required": false; "isSignal": true; }; "freeTextMaxLength": { "alias": "freeTextMaxLength"; "required": false; "isSignal": true; }; }, { "formSubmit": "formSubmit"; }, never, ["drv-button"], true, never>;
}

declare class BlankpageComponent {
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<BlankpageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<BlankpageComponent, "drv-blankpage", never, { "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class ApppageComponent {
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    readonly _buttons: _angular_core.Signal<readonly any[]>;
    get hasHelpButton(): boolean;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ApppageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ApppageComponent, "drv-apppage", never, { "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; }, {}, ["_buttons"], ["drv-progressbar", "drv-navigation", "drv-progressnav", "drv-button.drv-help-btn", "*"], true, never>;
}

declare class StartpageComponent {
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<StartpageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<StartpageComponent, "drv-startpage", never, { "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; }, {}, never, ["[drv-startpage-content]", "[drv-startpage-aside]"], true, never>;
}

declare class ContentpageComponent {
    readonly fullWidth: _angular_core.InputSignal<boolean>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ContentpageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ContentpageComponent, "drv-contentpage", never, { "fullWidth": { "alias": "fullWidth"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

interface FormAutoFocusConfig {
    onInit?: FocusFirstType;
    onSubmit?: FocusFirstWithErrorType;
    focusOrigin?: FocusOrigin;
}
type FocusFirstType = 'none' | 'focusFirst' | 'focusFirstRequired';
type FocusFirstWithErrorType = FocusFirstType | 'focusFirstWithError';
declare class FormAutoFocusDirective implements AfterViewInit, OnDestroy {
    private readonly formGroupDirective;
    private readonly focusMonitor;
    private readonly repository;
    readonly formGroup: _angular_core.InputSignal<FormGroup<any>>;
    readonly formAutoFocusConfig: _angular_core.InputSignal<FormAutoFocusConfig>;
    formControls: QueryList<FormControlName>;
    private readonly subscriptions;
    constructor();
    get config(): FormAutoFocusConfig;
    ngAfterViewInit(): void;
    ngOnDestroy(): void;
    focusFirst(): void;
    focusFirstRequired(): void;
    submittedFocusFirstWithError(): void;
    private registerOnSubmitHook;
    private switchFocus;
    private focusControl;
    private focusElement;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<FormAutoFocusDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<FormAutoFocusDirective, "[drv-form-auto-focus]", never, { "formGroup": { "alias": "formGroup"; "required": true; "isSignal": true; }; "formAutoFocusConfig": { "alias": "formAutoFocusConfig"; "required": true; "isSignal": true; }; }, {}, ["formControls"], never, true, never>;
}

declare class ShortcutDirective implements OnInit {
    private elRef;
    private renderer;
    readonly shortcut: _angular_core.InputSignal<string>;
    ngOnInit(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ShortcutDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<ShortcutDirective, "[drv-keyshortcuts]", never, { "shortcut": { "alias": "drv-keyshortcuts"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface EventInfo {
    icon: IconType;
    text: string;
}
declare class EventteaserComponent {
    private document;
    readonly highlight: _angular_core.InputSignal<boolean>;
    readonly firstDate: _angular_core.InputSignal<Date>;
    readonly secondDate: _angular_core.InputSignal<Date>;
    readonly hint: _angular_core.InputSignal<string>;
    readonly warningPrefix: _angular_core.InputSignal<string>;
    readonly moreDates: _angular_core.InputSignal<string>;
    readonly nextEvent: _angular_core.InputSignal<string>;
    readonly title: _angular_core.InputSignal<string>;
    readonly link: _angular_core.InputSignal<string>;
    readonly infos: _angular_core.InputSignal<EventInfo[]>;
    hostTitle: any;
    protected trackByFn: (index: number) => number;
    get cssClass(): string;
    get ariaLabel(): string;
    get dateTimes(): string[];
    get displayDates(): string[];
    get locale(): string;
    private format;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<EventteaserComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<EventteaserComponent, "drv-eventteaser", never, { "highlight": { "alias": "highlight"; "required": false; "isSignal": true; }; "firstDate": { "alias": "firstDate"; "required": false; "isSignal": true; }; "secondDate": { "alias": "secondDate"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "warningPrefix": { "alias": "warningPrefix"; "required": false; "isSignal": true; }; "moreDates": { "alias": "moreDates"; "required": false; "isSignal": true; }; "nextEvent": { "alias": "nextEvent"; "required": false; "isSignal": true; }; "title": { "alias": "title"; "required": false; "isSignal": true; }; "link": { "alias": "link"; "required": false; "isSignal": true; }; "infos": { "alias": "infos"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class AriaAccordionItemComponent extends AccordionItemComponent implements AfterViewInit {
    /** @internal */
    readonly btnElement: _angular_core.Signal<ElementRef<any>>;
    readonly itemId: _angular_core.InputSignal<string>;
    readonly headingLevel: _angular_core.InputSignal<"h1" | "h2" | "h3" | "h4" | "h5" | "h6">;
    get open(): boolean | null;
    /** @internal */
    emitToggle(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AriaAccordionItemComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AriaAccordionItemComponent, "drv-aria-accordionitem", never, { "itemId": { "alias": "itemId"; "required": false; "isSignal": true; }; "headingLevel": { "alias": "headingLevel"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

declare class AriaAccordionComponent extends AccordionComponent implements AfterViewInit {
    readonly ariaItems: _angular_core.Signal<readonly AriaAccordionItemComponent[]>;
    private expandedAriaItems;
    /**
     * @returns {AriaAttributes} aria attributes
     * @internal
     */
    get buttonAriaAttributes(): AriaAttributes;
    /** @internal */
    toggleAll(): void;
    ngAfterViewInit(): void;
    private closeOtherArias;
    private initAriaWatchers;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AriaAccordionComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<AriaAccordionComponent, "drv-aria-accordion", never, {}, {}, ["ariaItems"], ["[headline]", "*"], true, never>;
}

declare class ApplicationNavigationComponent implements AfterContentInit {
    private router;
    readonly navs: _angular_core.Signal<readonly NavigationListComponent[]>;
    readonly navLabel: _angular_core.InputSignal<string>;
    readonly showLogo: _angular_core.InputSignal<boolean>;
    readonly isExpandable: _angular_core.InputSignal<boolean>;
    readonly expandButtonLabelOpen: _angular_core.InputSignal<string>;
    readonly expandButtonLabelClose: _angular_core.InputSignal<string>;
    readonly logoLink: _angular_core.InputSignal<string>;
    readonly logoLinkRoute: _angular_core.InputSignal<string[] | Route[]>;
    readonly logoLinkRouteExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly logoLinkTitle: _angular_core.InputSignal<string>;
    readonly logoAltText: _angular_core.InputSignal<string>;
    protected isOpen: boolean;
    get logoHref(): string;
    ngAfterContentInit(): void;
    protected toggle(): void;
    protected onLogoClick(e: MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<ApplicationNavigationComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<ApplicationNavigationComponent, "drv-application-navigation", never, { "navLabel": { "alias": "navLabel"; "required": true; "isSignal": true; }; "showLogo": { "alias": "showLogo"; "required": false; "isSignal": true; }; "isExpandable": { "alias": "isExpandable"; "required": false; "isSignal": true; }; "expandButtonLabelOpen": { "alias": "expandButtonLabelOpen"; "required": false; "isSignal": true; }; "expandButtonLabelClose": { "alias": "expandButtonLabelClose"; "required": false; "isSignal": true; }; "logoLink": { "alias": "logoLink"; "required": false; "isSignal": true; }; "logoLinkRoute": { "alias": "logoLinkRoute"; "required": false; "isSignal": true; }; "logoLinkRouteExtras": { "alias": "logoLinkRouteExtras"; "required": false; "isSignal": true; }; "logoLinkTitle": { "alias": "logoLinkTitle"; "required": false; "isSignal": true; }; "logoAltText": { "alias": "logoAltText"; "required": false; "isSignal": true; }; }, {}, ["navs"], ["*"], true, never>;
}

type CardVariant = 'default' | 'overlayed-actions';
declare class CardContentDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardContentDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CardContentDirective, "drv-card-content", never, {}, {}, never, never, true, never>;
}
declare class CardActionsDirective {
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardActionsDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<CardActionsDirective, "drv-card-actions", never, {}, {}, never, never, true, never>;
}
declare class CardComponent {
    readonly clickable: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly variant: _angular_core.InputSignal<CardVariant>;
    readonly cardId: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardComponent, "drv-card", never, { "clickable": { "alias": "clickable"; "required": false; "isSignal": true; }; "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "cardId": { "alias": "cardId"; "required": true; "isSignal": true; }; }, {}, never, ["drv-card-header", "drv-card-content", "drv-card-actions"], true, never>;
}

declare class CardHeaderComponent {
    readonly cardTitle: _angular_core.InputSignal<string>;
    readonly cardId: _angular_core.InputSignal<string>;
    readonly subtitle: _angular_core.InputSignal<string>;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardHeaderComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardHeaderComponent, "drv-card-header", never, { "cardTitle": { "alias": "cardTitle"; "required": true; "isSignal": true; }; "cardId": { "alias": "cardId"; "required": true; "isSignal": true; }; "subtitle": { "alias": "subtitle"; "required": false; "isSignal": true; }; }, {}, never, ["drv-checkbox", "drv-radiobutton", "drv-button", "drv-overflowmenu", "*"], true, never>;
}

type CardImageVariant = 'portrait-2x3' | 'portrait-3x4' | 'landscape-4x3' | 'landscape-1x1';
declare class CardImageComponent {
    readonly variant: _angular_core.InputSignal<CardImageVariant>;
    readonly fill: _angular_core.InputSignalWithTransform<boolean, unknown>;
    protected get containerCssClasses(): string;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CardImageComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CardImageComponent, "drv-card-image", never, { "variant": { "alias": "variant"; "required": false; "isSignal": true; }; "fill": { "alias": "fill"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

type DefaultCalendarView = 'month-grid' | 'week' | 'day';
interface DateRange {
    start: string;
    end: string;
}
declare class CalendarComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {
    private deviceService;
    readonly events: _angular_core.InputSignal<CalendarEvent[]>;
    readonly calendarName: _angular_core.InputSignal<string>;
    readonly dayStartsAt: _angular_core.InputSignal<string>;
    readonly dayEndsAt: _angular_core.InputSignal<string>;
    readonly defaultView: _angular_core.InputSignal<DefaultCalendarView>;
    readonly minDate: _angular_core.InputSignal<string>;
    readonly maxDate: _angular_core.InputSignal<string>;
    readonly hasWeekendStyled: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly eventClicked: _angular_core.OutputEmitterRef<CalendarEvent>;
    readonly rangeUpdated: _angular_core.OutputEmitterRef<DateRange>;
    readonly container: _angular_core.Signal<ElementRef<any>>;
    protected locale: string;
    protected calendarApp: CalendarApp;
    protected activeView: number;
    protected controls: ReturnType<typeof createCalendarControlsPlugin>;
    protected eventsService: ReturnType<typeof createEventsServicePlugin>;
    protected currentTime: ReturnType<typeof createCurrentTimePlugin>;
    protected activeDate: string;
    protected calendarTitle: string;
    private pluginDateFormat;
    private titleFormat;
    private dateFormat;
    private calendarConfig;
    constructor();
    protected get monthView(): string;
    ngOnInit(): void;
    ngAfterViewInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    protected onViewChange(index: number): void;
    protected jumpToToday(): void;
    protected onDateChange(): void;
    protected onRender(): void;
    protected onRangeUpdate(range: DateRange): void;
    protected navigate(direction?: number): void;
    private onEventClickHandler;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<CalendarComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<CalendarComponent, "drv-calendar", never, { "events": { "alias": "events"; "required": false; "isSignal": true; }; "calendarName": { "alias": "calendarName"; "required": false; "isSignal": true; }; "dayStartsAt": { "alias": "dayStartsAt"; "required": false; "isSignal": true; }; "dayEndsAt": { "alias": "dayEndsAt"; "required": false; "isSignal": true; }; "defaultView": { "alias": "defaultView"; "required": false; "isSignal": true; }; "minDate": { "alias": "minDate"; "required": false; "isSignal": true; }; "maxDate": { "alias": "maxDate"; "required": false; "isSignal": true; }; "hasWeekendStyled": { "alias": "hasWeekendStyled"; "required": false; "isSignal": true; }; }, { "eventClicked": "eventClicked"; "rangeUpdated": "rangeUpdated"; }, never, never, true, never>;
}

declare class OverflowmenuModernComponent implements AfterContentInit {
    readonly id: _angular_core.InputSignal<string>;
    readonly placing: _angular_core.InputSignal<OverflowmenuPlacing>;
    readonly triggerButtonLabel: _angular_core.InputSignal<string>;
    readonly triggerButtonVariant: _angular_core.InputSignal<OverflowmenuBtnVariant>;
    readonly triggerButtonIcon: _angular_core.InputSignal<IconType>;
    readonly triggerButtonIconOnly: _angular_core.InputSignal<IconOnlyType>;
    readonly triggerButtonIconPosition: _angular_core.InputSignal<IconPositionType>;
    /** @internal */
    readonly buttons: _angular_core.Signal<readonly ButtonComponent[]>;
    /** @internal */
    readonly toggleButton: _angular_core.Signal<ElementRef<any>>;
    /** @internal */
    readonly menuContent: _angular_core.Signal<ElementRef<HTMLElement>>;
    protected isOpen: boolean;
    protected trackByFn: (index: number) => number;
    constructor();
    /** @internal */
    ngAfterContentInit(): void;
    protected toggle(event: Event): void;
    private calculatePosition;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<OverflowmenuModernComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<OverflowmenuModernComponent, "drv-overflowmenu-modern", never, { "id": { "alias": "id"; "required": false; "isSignal": true; }; "placing": { "alias": "placing"; "required": false; "isSignal": true; }; "triggerButtonLabel": { "alias": "triggerButtonLabel"; "required": true; "isSignal": true; }; "triggerButtonVariant": { "alias": "triggerButtonVariant"; "required": false; "isSignal": true; }; "triggerButtonIcon": { "alias": "triggerButtonIcon"; "required": false; "isSignal": true; }; "triggerButtonIconOnly": { "alias": "triggerButtonIconOnly"; "required": false; "isSignal": true; }; "triggerButtonIconPosition": { "alias": "triggerButtonIconPosition"; "required": false; "isSignal": true; }; }, {}, ["buttons"], never, true, never>;
}

declare class TeaserComponent {
    private router;
    readonly title: _angular_core.InputSignal<string>;
    readonly teaserText: _angular_core.InputSignal<string>;
    readonly linkText: _angular_core.InputSignal<string>;
    readonly externalLinkText: _angular_core.InputSignal<string>;
    readonly href: _angular_core.InputSignal<string>;
    readonly target: _angular_core.InputSignal<IconLinkTarget>;
    readonly route: _angular_core.InputSignal<string[] | Route[]>;
    readonly routeExtras: _angular_core.InputSignal<NavigationExtras>;
    readonly isExternalLink: _angular_core.InputSignalWithTransform<boolean, unknown>;
    readonly itemClick: _angular_core.OutputEmitterRef<MouseEvent>;
    protected get getHref(): string;
    protected onClickHandler(event: PointerEvent | MouseEvent): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<TeaserComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<TeaserComponent, "drv-teaser", never, { "title": { "alias": "title"; "required": true; "isSignal": true; }; "teaserText": { "alias": "teaserText"; "required": false; "isSignal": true; }; "linkText": { "alias": "linkText"; "required": true; "isSignal": true; }; "externalLinkText": { "alias": "externalLinkText"; "required": false; "isSignal": true; }; "href": { "alias": "href"; "required": false; "isSignal": true; }; "target": { "alias": "target"; "required": false; "isSignal": true; }; "route": { "alias": "route"; "required": false; "isSignal": true; }; "routeExtras": { "alias": "routeExtras"; "required": false; "isSignal": true; }; "isExternalLink": { "alias": "isExternalLink"; "required": false; "isSignal": true; }; }, { "itemClick": "itemClick"; }, never, ["drv-pictogram, picture, img"], true, never>;
}

interface AppConfig {
    spritePath: string;
    pictogramSpritePath: string;
    formsRequiredDefault: boolean;
    formsRequiredDefaultSign: string;
    formsOptionalDefaultText: string;
    progressnavDefaultDisabled: boolean;
    notificationDefaultToastPosition: NotificationToastPosition;
    applicationHeaderDefaultLayout: ApplicationHeaderLayout;
    showKeyboardshortCutAsTooltip: boolean;
    reducedMotion: boolean;
    useTheme: boolean;
    themePath?: string;
    symbolsPath: string;
}
declare const CONFIG_TOKEN: InjectionToken<Partial<AppConfig>>;
declare const DEFAULT_CONFIG_PUBLIC: AppConfig;
declare const DEFAULT_CONFIG_PRODUCTIVE: AppConfig;

export { AccordionComponent, AccordionItemComponent, ApplicationHeaderComponent, ApplicationNavigationComponent, ApppageComponent, AriaAccordionComponent, AriaAccordionItemComponent, BlankpageComponent, BreadcrumbComponent, ButtonComponent, ButtonbarComponent, CONFIG_TOKEN, CalendarComponent, CardActionsDirective, CardComponent, CardContentDirective, CardHeaderComponent, CardImageComponent, CheckboxComponent, ColDirective, CollapsibleComponent, ComboboxComponent, ContentpageComponent, DEFAULT_CONFIG_PRODUCTIVE, DEFAULT_CONFIG_PUBLIC, DatepickerComponent, DatepickerLegacyComponent, DetailsComponent, DonutComponent, DropdownComponent, DropdownService, EmptyStateComponent, EventteaserComponent, FieldsetComponent, FileListComponent, FilterComponent, FooterComponent, FormAutoFocusDirective, FormerrorsComponent, FormitemComponent, GridDirective, HeaderComponent, IconComponent, IconlinkComponent, IcontextComponent, InputGroupComponent, InsuranceNumberComponent, InsuranceNumberFormatPipe, ItemlistAnimatedComponent, ItemlistComponent, ItemlistItemComponent, JumplinksComponent, LabelComponent, LinklistComponent, ListComponent, LoadingComponent, LoadingService, MediaComponent, ModalActionsDirective, ModalComponent, ModalContentDirective, ModalLegacyComponent, ModalLegacyService, ModalService, NFComponent, NavigationComponent, NavigationListComponent, NotificationComponent, NotificationService, OptionGroupComponent, OverflowmenuComponent, OverflowmenuModernComponent, OverflowselectComponent, PaginationComponent, PasswordComponent, PictogramComponent, ProgressBarComponent, ProgressnavComponent, ProgressnavNodeComponent, ProgressnavService, RadiobuttonComponent, RichtextComponent, RootComponent, RowDirective, SearchbarComponent, SegmentedButtonComponent, SelectBoxComponent, ShortcutDirective, SidepanelActionsDirective, SidepanelComponent, SidepanelContentDirective, SidepanelService, SliderComponent, SpacerComponent, SpinnerComponent, StageComponent, StarRatingComponent, StartpageComponent, StatusComponent, StatusScreenComponent, SubProgressnavComponent, SubTreeViewComponent, SummaryComponent, TableAnimatedComponent, TableComponent, TableExpandRowComponent, TableExpandedRowComponent, TableHeadComponent, TablistComponent, TabpanelComponent, TeaserComponent, TextareaComponent, TextinputComponent, TileComponent, TimePickerComponent, ToggleComponent, ToggletipComponent, TooltipComponent, TreeViewComponent, TreeViewNodeComponent, UploadButtonComponent, UploadFieldComponent, ValueAccessorDirective, formatVSNR, formatValid };
export type { AppConfig, ApplicationHeaderLayout, AriaAttributes, AriaPressedType, BreadcrumbItemInterface, ButtonBarLayoutMobile, ButtonBarPlacing, ButtonBarVariant, ButtonKindType, ButtonTypeType, CardImageVariant, CardVariant, ChartSize, CheckboxChange, ClickFunction, CollapsibleOnlyType, ComboboxAutoCompleteOptions, DateLimit, DateOption, DateRange, DateRangeLimit, DefaultCalendarView, DisableDatesFn, DrvComboboxOption, DrvDropdownOption, EmptyStatePictogramPosition, EventInfo, FieldsetLegendStyle, FieldsetShortcut, FileListItem, FilterOptions, FocusFirstType, FocusFirstWithErrorType, FooterLinkItem, FormAutoFocusConfig, FormError, FormItemMessage, FullSizeOptionType, H1StyleType, IconLinkData, IconLinkSize, IconLinkTarget, IconLinkType, IconLinkVariant, IconOnlyType, IconPositionType, IconType, IcontextHeadingClass, IcontextTagname, IcontextVariant, JumplinkData, LangLinkItem, LinkTargetType, LinklistColumns, LinklistData, LinklistPositions, LinklistType, Loading, MainNavLinkItem, MetanavLinkItem, Modal, ModalClosedBy, ModalRole, MonthSelectorType, NavigationItem, NavigationItemAction, NfcFeedbackResult, Notification, NotificationToastPosition, NotificationType, NotificationVariant, OnSelectChange, OverflowmenuBtnVariant, OverflowmenuPlacing, OverflowselectBtnVariant, OverflowselectOption, OverflowselectPlacing, PaginationVariant, PictogramsType, PlacementType, RadioChange, SearchbarVariant, SelectBoxOption, SetGroup, SidepanelSize, SidepanelVariant, SliderComponentVariant, SortEvent, SortFunction, SpacerContentPlacing, SpacingVariant, StatusBgColor, StatusLayout, StatusVariant, SummaryLayoutType, SummaryMainInfoHighlight, SummaryVariantType, TabChange, TableData, TableDataBody, TableHeaderItem, TableHeaderItemAlignmentType, TableHeaderItemCollapseType, TableHeaderItemOrderType, TableHeaderItemUnitType, TextInputAlign, TextInputMode, TextInputType, ToggleChange, ToggleLabelStyle, ToggleLayout, UploadFieldVariantType };
