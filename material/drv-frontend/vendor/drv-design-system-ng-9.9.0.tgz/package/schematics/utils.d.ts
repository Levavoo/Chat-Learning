import { Rule, Tree } from '@angular-devkit/schematics';
import { workspaces } from '@angular-devkit/core';
declare const getComponentPath: (tree: Tree, projectParameter: string) => Promise<string>;
declare const updateAppWithComponent: (name: string, path: string, subfolder?: string) => Rule;
declare const addImportAndDeclaration: (source: string, componentName: string, componentPath: string) => string;
declare const getSingleProjectName: (workspace: workspaces.WorkspaceDefinition) => string;
export { getComponentPath, updateAppWithComponent, addImportAndDeclaration, getSingleProjectName };
